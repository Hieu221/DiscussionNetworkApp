package core;



import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.Arrays;
import java.util.List;

import utility.ProfilePageSortStrategy;

/**
 * Test class for NetworkSystem
 * Directly tests handleAgreeAction, handleDisagreeAction, handleRepostAction, and handleDeleteAction methods.
 * @author Tabbie Brantley and Selin Topac
 */
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import gui.*;
import core.*;


public class NetworkSystemTest {
    
    public NetworkSystemTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }


    /**
     * Test of setCurrentUser method, of class NetworkSystem.
     */
    @Test
    public void testSetCurrentUser() {
        System.out.println("setCurrentUser");
        System.out.println("getCurrentUser");
        UserAccount user = new UserAccount("accountName", "username", "password");
        NetworkSystem instance = NetworkSystem.getInstance();
        instance.getUserAccountsList().put("username", user);
        instance.setCurrentUser(user);
        UserAccount expResult = user;
        UserAccount result = instance.getCurrentUser();
        assertEquals(expResult, result);
    }


    /**
     * @author Tabbie Brantley
     * Test of getCurrentUser method, of class NetworkSystem.
     */
    @Test
    public void testGetCurrentUser() {
        System.out.println("getCurrentUser");
        UserAccount user = new UserAccount("accountName", "username", "password");
        NetworkSystem instance = NetworkSystem.getInstance();
        instance.getUserAccountsList().put("username", user);
        instance.setCurrentUser(user);
        UserAccount expResult = user;
        UserAccount result = instance.getCurrentUser();
        assertEquals(expResult, result);
    }

    /**
     * @author Tabbie Brantley
     * Test of checkUserExists method, of class NetworkSystem.
     */
    @Test
    public void testCheckUserExists() {
        System.out.println("checkUserExists");
        NetworkSystem instance = NetworkSystem.getInstance();
        String un = "username";
        String pwd = "password";
        String accountName = "accountName";
        //when it should exist
        instance.addUserAccount(accountName, un, pwd);
        boolean expResult = true;
        boolean result = instance.checkUserExists(un);
        assertEquals(expResult, result);

        //when it shouldn't exist
        boolean expResult2 = false;
        boolean result2 = instance.checkUserExists("incorrect");
        assertEquals(expResult, result);
    }



    /**
     * @author Tabbie Brantley
     * Test of getHeight method, of class NetworkSystem.
     */
    @Test
    public void testGetHeight() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        System.out.println("getHeight");
        int expResult = screenSize.height;
        int result = NetworkSystem.getInstance().getHeight();
        assertEquals(expResult, result);

    }

    /**
     * @author Tabbie Brantley
     * Test of getWidth method, of class NetworkSystem.
     */
    @Test
    public void testGetWidth() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        System.out.println("getWidth");
        int expResult = screenSize.width;
        int result = NetworkSystem.getInstance().getWidth();
        assertEquals(expResult, result);
    }



    /**
     * @author Tabbie Brantley
     * Test of usernameExists method, of class NetworkSystem.
     */
    @Test
    public void testUsernameExists() {
        NetworkSystem instance = NetworkSystem.getInstance();
        String un = "username";
        String pwd = "password";
        String accountName = "accountName";
        //when it should exist
        instance.addUserAccount(accountName, un, pwd);
        boolean expResult = true;
        boolean result = instance.usernameExists(un);
        assertEquals(expResult, result);

        //when it shouldn't exist
        boolean expResult2 = false;
        boolean result2 = instance.usernameExists("incorrect");
        assertEquals(expResult, result);
    }

    /**
    * @author Tabbie Brantley
    * Test of loginUser method, of class NetworkSystem. Making sure the correct user was logged in
    */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        NetworkSystem instance = NetworkSystem.getInstance();
        String un = "username";
        String pwd = "password";
        String accountName = "accountName";
        //when it should log in
        instance.addUserAccount(accountName, un, pwd);
        boolean expResult = true;
        boolean result = instance.loginUser(un, pwd);
        assertEquals(expResult, result);

        //when it shouldn't log in
        boolean expResult2 = false;
        boolean result2 = instance.loginUser(un, "incorrect");
        assertEquals(expResult, result);
    }


     /**
     * @author TabbieBrantley
     * Test of logout method, of class NetworkSystem. Testing that the current user is set to null
     */
    @Test
    public void testLogout() {
        System.out.println("logout");
        NetworkSystem instance = NetworkSystem.getInstance();
        instance.setCurrentUser(new UserAccount("accountname", "username", "password"));
        instance.logout();
        assertEquals(null, instance.getCurrentUser());
    }

    /**

    /**
     * @author Tabbie Brantley
     * 
     * test for updating points
     */
    @Test
    public void testUpdatePointForUser(){
        System.out.println("updatePointForUser");
        NetworkSystem.getInstance().addUserAccount("name", "usernametest", "password");
        int val = 1;
        NetworkSystem instance = NetworkSystem.getInstance();
        instance.updatePointForUser("usernametest", val);
        assertEquals(instance.getUserAccountsList().get("usernametest").getPoints(), val);
    }

    /**
     * @author Selin Topac
     * 
     * test for addinging a user account
     */
    @Test
    public void testAddUserAccount() {

        NetworkSystem.getInstance().addUserAccount("accounttest", "testname", "password");

        assertEquals(1, NetworkSystem.getInstance().getUserAccountsList().size());

        assertNotNull(NetworkSystem.getInstance().getUserAccountsList().get("testname"));

    }

}
