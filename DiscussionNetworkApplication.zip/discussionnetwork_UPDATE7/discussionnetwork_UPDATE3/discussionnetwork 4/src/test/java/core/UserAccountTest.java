/**
 * @author Tabbie Brantley
 * UserAccountTest tests for UserAccount
 */

package core;

import static org.junit.jupiter.api.Assertions.*;


public class UserAccountTest {
    
    public UserAccountTest() {
    }

    @org.junit.jupiter.api.BeforeAll
    public static void setUpClass() throws Exception {
    }

    @org.junit.jupiter.api.AfterAll
    public static void tearDownClass() throws Exception {
    }

    @org.junit.jupiter.api.BeforeEach
    public void setUp() throws Exception {
    }

    @org.junit.jupiter.api.AfterEach
    public void tearDown() throws Exception {
    }
    
    

    /**
     * Test of getUsername method, of class UserAccount.
     */
    @org.junit.jupiter.api.Test
    public void testGetUsername() {
        System.out.println("getUsername");
        //testing getting the username
        UserAccount user = new UserAccount("AccountName", "Username", "Password");
        String expResult = "Username";
        String notExpResult = "Bad result";
        assertEquals(expResult, user.getUsername());
        assertNotEquals(notExpResult, user.getUsername());
    }
    
    /**
     * Test of getPassword method, of class UserAccount.
     */
    @org.junit.jupiter.api.Test
    public void testGetPassword() {
        //testing getting the password
        System.out.println("getPassword");
        UserAccount user = new UserAccount("AccountName", "Username", "Password");
        String expResult = "Password";
        String result = user.getPassword();
        assertEquals(expResult, result);
    }

    /**
     * Test of getPoints method, of class UserAccount.
     */
    @org.junit.jupiter.api.Test
    public void testGetPoints() {
        //testing getting the points
        System.out.println("getPoints");
        UserAccount user = new UserAccount("AccountName", "Username", "Password");
        int expResult = 0;
        int result = user.getPoints();
        assertEquals(expResult, result);
    }

    /**
     * Test of updatePoint method, of class UserAccount.
     */
    @org.junit.jupiter.api.Test
    public void testUpdatePoints() {
        //testing adding a positive number
        System.out.println("updatePoints");
        int number = 1;
        UserAccount user = new UserAccount("AccountName", "Username", "Password");
        user.updatePoints(number);
        int expResult = 1;
        assertEquals(expResult, user.getPoints());
        
        //testing when it is 1 and making it a 0
        int number2 = -1;
        user.updatePoints(number2);
        int expResult2 = 0;
        assertEquals(expResult2, user.getPoints());
        
        //testing when it is 1, and going down by -2, so points should be 0
        //since cannot have negative points
        int number3 = 1;
        user.updatePoints(number3);
        //the points should be 1 now, so update by -2
        int number4 = -2;
        user.updatePoints(number4);
        int expResult3 = 0;
        assertEquals(expResult3, user.getPoints());
    }

    /**
     * Test of setName method, of class UserAccount.
     */
    @org.junit.jupiter.api.Test
    public void testSetName() {
        //testing that the name was right
        System.out.println("setName");
        UserAccount user = new UserAccount("AccountName", "Username", "Password");
        System.out.println("setName");
        String newName = "newName";
        user.setName(newName);
        assertEquals(newName, user.getAccountName());
    }

    /**
     * Test of setPassword method, of class UserAccount.
     */
    @org.junit.jupiter.api.Test
    public void testSetPassword() {
        //testing that the password was set right
        System.out.println("setPassword");
        UserAccount user = new UserAccount("AccountName", "Username", "Password");
        System.out.println("setPassword");
        String newPassword= "newPassword";
        user.setPassword(newPassword);
        assertEquals(newPassword, user.getPassword());
    }

    /**
     * Test of getAccountName method, of class UserAccount.
     */
    @org.junit.jupiter.api.Test
    public void testGetAccountName() {
        //testing getting the name
        System.out.println("getAccountName");
        UserAccount user = new UserAccount("AccountName", "Username", "Password");
        String expResult = "AccountName";
        String result = user.getAccountName();
        assertEquals(expResult, result);
    }
    
}
