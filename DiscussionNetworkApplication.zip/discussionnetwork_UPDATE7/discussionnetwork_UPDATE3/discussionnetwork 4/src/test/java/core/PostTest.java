package core;

import javax.swing.JButton;
import javax.swing.JPanel;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import utility.*;

/**
 * PostTest tests for class Post
 * @author Hieu Truong
 */
public class PostTest {
    
    public PostTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of setID method, of class Post.
     */
    @Test
    public void testSetID() {
        System.out.println("setID");
        int id = 1;
        Post instance = new UserPost("Test Title", new UserAccount("testName", "testUsername", "testpPass"));
        instance.setID(id);
        assertEquals(id, instance.getPostID(), "The ID should be correctly set.");
    }

    /**
     * Test of updatePoint method, of class Post.
     */
    @Test
    public void testUpdatePoint() {
        System.out.println("updatePoint");
        int points = 5;
        Post instance = new UserPost("Test Title", new UserAccount("testName", "testUsername", "testpPass"));
        int initialPoints = instance.getPoints(); // Assume there's a method to get points.
        instance.updatePoint(points);
        assertEquals(initialPoints + points, instance.getPoints(), "The points should be updated correctly.");
    }

    /**
     * Test of setCategory method, of class Post.
     */
    @Test
    public void testSetCategory() {
        System.out.println("setCategory");
        String category = "Sports";
        Post instance = new UserPost("Test Title", new UserAccount("testName", "testUsername", "testpPass"));
        instance.setCategory(category);
        // TODO review the generated test code and remove the default call to fail.
        assertEquals(category, instance.getCategory(), "The points should be updated correctly.");
    }

    /**
     * Test of getOwner method, of class Post.
     */
    @Test
    public void testGetOwner() {
        System.out.println("getOwner");
        UserAccount expectedOwner = new UserAccount("testName", "testUsername", "testPass");
        Post instance = new UserPost("Test Title", expectedOwner);
        UserAccount result = instance.getOwner();
        assertEquals(result.getUsername(), expectedOwner.getUsername());
    }

    /**
     * Test of getCategory method, of class Post.
     */
    @Test
    public void testGetCategory() {
        System.out.println("getCategory");
        Post instance = new UserPost("Test Title", new UserAccount("testName", "testUsername", "testpPass"));
        instance.setCategory("Sport");
        String expResult = "Sport";
        String result = instance.getCategory();
        assertEquals(expResult, result);
    }

    /**
     * Test of getPostID method, of class Post.
     */
    @Test
    public void testGetPostID() {
        System.out.println("getPostID");
        Post instance = new UserPost("Test Title", new UserAccount("testName", "testUsername", "testpPass"));
        instance.setID(1);
        int expResult = 1;
        int result = instance.getPostID();
        assertEquals(expResult, result);
    }

    /**
     * Test of addInteract method, of class Post.
     */
    @Test
    public void testAddInteract() {
        System.out.println("addInteract");
        String username = "user1";
        String interact = "Agree";
        Post instance = new UserPost("Test Title", new UserAccount("testName", "testUsername", "testPass"));
        instance.addInteract(username, interact);
        String result = instance.getInteract(username);
        assertEquals(interact, result);
    }

    /**
     * Test of removeInteract method, of class Post.
     */
    @Test
    public void testRemoveInteract() {
        System.out.println("removeInteract");
        String username = "user1";
        Post instance = new UserPost("Test Title", new UserAccount("testName", "testUsername", "testPass"));

        instance.addInteract(username, "Agree");
        instance.removeInteract(username);
        String result = instance.getInteract(username);

        assertEquals(result, "");
    }

    /**
     * Test of getInteract method, of class Post.
     */
    @Test
    public void testGetInteract() {
        System.out.println("getInteract");
        String username = "user1";
        String interact = "Agree";
        Post instance = new UserPost("Test Title", new UserAccount("testName", "testUsername", "testPass"));
        instance.addInteract(username, interact);
        String expResult = "Agree";
        String result = instance.getInteract(username);
        assertEquals(expResult, result);
    }

    /**
     * Test of toString method, of class Post.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Post instance = new UserPost("Test Title", new UserAccount("testName", "testUsername", "testPass"));
        String result = instance.toString();
        String expResult = "Test Title testName";
        assertEquals(expResult, result);
    }

    /**
     * Test of getThisPostPanel method, of class Post.
     */
    @Test
    public void testGetThisPostPanel() {
        System.out.println("getThisPostPanel");
        Post instance = new UserPost("Test Title", new UserAccount("testName", "testUsername", "testPass"));
        JPanel result = instance.getThisPostPanel();
        assertNotNull(result, "getThisPostPanel should return a non-null JPanel.");
    }

    /**
     * Test of getExtraDetail method, of class Post.
     */
    @Test
    public void testGetExtraDetail() {
        System.out.println("getExtraDetail");
        Post instance = new UserPost("Test Title", new UserAccount("testName", "testUsername", "testPass"));
        Post instance2 = new Repost("Test Title", new UserAccount("testName", "testUsername", "testPass"), instance);
        JPanel result = instance2.getExtraDetail();
        assertNotNull(result, "getExtraDetail should return a non-null JPanel with extra details.");
    }

    /**
     * Test of getCompletePostPanel method, of class Post.
     */
    @Test
    public void testGetCompletePostPanel() {
        System.out.println("getCompletePostPanel");
        SortPostStrategy displayStrategy = new GeneralPageSortStrategy(); // Replace with actual strategy implementation
        Post instance = new UserPost("Test Title", new UserAccount("testName", "testUsername", "testPass"));
        JPanel result = instance.getCompletePostPanel(displayStrategy);
        assertNotNull(result, "getCompletePostPanel should return a non-null JPanel using the strategy.");
    }

    /**
     * Test of getAgreeButton method, of class Post.
     */
    @Test
    public void testGetAgreeButton() {
        System.out.println("getAgreeButton");
        Post instance = new UserPost("Test Title", new UserAccount("testName", "testUsername", "testPass"));
        instance.getCompletePostPanel(new GeneralPageSortStrategy());
        JButton result = instance.getAgreeButton();
        assertNotNull(result, "getAgreeButton should return a non-null JButton.");
        assertEquals("Agree", result.getText(), "Agree button should have the correct text.");
        
    }

    /**
     * Test of getDisagreeButton method, of class Post.
     */
    @Test
    public void testGetDisagreeButton() {
        System.out.println("getAgreeButton");
        Post instance = new UserPost("Test Title", new UserAccount("testName", "testUsername", "testPass"));
        instance.getCompletePostPanel(new GeneralPageSortStrategy());
        JButton result = instance.getDisagreeButton();
        assertNotNull(result, "getDisagreeButton should return a non-null JButton.");
        assertEquals("Disagree", result.getText(), "Disagreebutton should have the correct text.");
    }

    public class PostImpl extends Post {

        public PostImpl() {
            super("", null);
        }

        public JPanel getExtraDetail() {
            return null;
        }
    }
    
}
