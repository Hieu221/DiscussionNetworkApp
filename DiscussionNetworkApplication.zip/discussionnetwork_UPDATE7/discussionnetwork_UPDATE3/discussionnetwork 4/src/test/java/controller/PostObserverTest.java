package controller;

import core.Post;
import core.Repost;
import core.NetworkSystem;
import core.UserAccount;
import core.UserPost;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import utility.ProfilePageSortStrategy;

/**
 * Test class for PostObserver.
 * Directly tests handleAgreeAction, handleDisagreeAction, handleRepostAction, and handleDeleteAction methods.
 * @author thuhieu
 */
public class PostObserverTest {

    private Post mockPost;
    private PostObserver observer;
    private NetworkSystem networkSystem;
    private UserAccount currentUser;

    @BeforeEach
    public void setUp() {
        // Mock current user in NetworkSystem
        networkSystem = NetworkSystem.getInstance();
        
        networkSystem.addUserAccount("name1", "username1", "pass1");
        networkSystem.addUserAccount("name2", "username2", "pass2");
        networkSystem.addPosts(new UserPost("title1", networkSystem.getUserAccountsList().get("username1")));
        networkSystem.addPosts(new UserPost("title2", networkSystem.getUserAccountsList().get("username2")));
          
        mockPost = new UserPost("titl mock", networkSystem.getUserAccountsList().get("username1"));
        observer = new PostObserver(mockPost);
        networkSystem.addPosts(mockPost);
        
        currentUser = networkSystem.getUserAccountsList().get("username1");
        networkSystem.setCurrentUser(currentUser);
        mockPost.getCompletePostPanel(new ProfilePageSortStrategy());
    }

    @Test
    public void testHandleAgreeAction() {
        int originalPoint = mockPost.getPoints();
        // First Agree action
        observer.handleAgreeAction(currentUser.getUsername());
        assertEquals(originalPoint+1, mockPost.getPoints(), "Points should increase by 1 for Agree action.");
        assertEquals("Agree", mockPost.getInteract(currentUser.getUsername()), "Interaction should be 'Agree'.");

        // Click Agree again (toggle off)
        observer.handleAgreeAction(currentUser.getUsername());
        assertEquals(originalPoint, mockPost.getPoints(), "Points should decrease by 1 when Agree is toggled off.");
    }

    @Test
    public void testHandleDisagreeAction() {
        int originalPoint = mockPost.getPoints();
        // First Disagree action
        observer.handleDisagreeAction(currentUser.getUsername());
        assertEquals(originalPoint-1, mockPost.getPoints(), "Points should decrease by 1 for Disagree action.");
        assertEquals("Disagree", mockPost.getInteract(currentUser.getUsername()), "Interaction should be 'Disagree'.");

        // Click Disagree again (toggle off)
        observer.handleDisagreeAction(currentUser.getUsername());
        assertEquals(originalPoint, mockPost.getPoints(), "Points should increase by 1 when Disagree is toggled off.");
    }

    @Test
    public void testHandleRepostAction() {
        assertDoesNotThrow(() -> observer.handleRepostAction(), "Repost action should not throw exceptions.");
    }

    @Test
    public void testHandleDeleteAction() {
        assertDoesNotThrow(() -> observer.handleDeleteAction(), "Delete action should not throw exceptions.");
    }
}
