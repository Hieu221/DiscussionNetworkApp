package  controller;
import gui.LeaderboardPage;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/*
 * @author Lewis Cox
 * LeaderboardControllerTest
 * 
 */
public class LeaderboardControllerTest {

    private LeaderboardController leaderboardController;
    private LeaderboardPage leaderboardPage;

    public LeaderboardControllerTest() {
    }

    @BeforeEach
    public void setUp() {
        
        leaderboardPage = new LeaderboardPage(null);
        leaderboardController = new LeaderboardController(leaderboardPage, null);
    }

    @AfterEach
    public void tearDown() {
        
    }

    /**
     * Test of updateLeaderboard method,
     */
    @Test
    public void testUpdateLeaderboard() {
        System.out.println("updateLeaderboard");

        
        leaderboardController.updateLeaderboard();

        
    }

    /**
     * Test of getTopPlayers method
     */
    @Test
    public void testGetTopPlayers() {
        System.out.println("getTopPlayers");

        

    
    }

    /**
     * Test of constructor method of c
     */
    @Test
    public void testConstructor() {
        System.out.println("Constructor");

        // Check if the controller is properly initialized with the leaderboardPage
        assertNotNull(leaderboardController, "LeaderboardController should not be null");
    }
}
