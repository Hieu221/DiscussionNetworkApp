/**
 * @author Tabbie Brantley
 * test class for ProfileController
 */
package controller;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import gui.*;
import core.*;

public class ProfileControllerTest {
    
    public ProfileControllerTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of checkNameLength method, of class ProfileController.
     */
    @Test
    public void testCheckNameLength() {
        System.out.println("checkNameLength");
        UserAccount user = new UserAccount("AccountName", "username", "password");
        ProfileController instance = new ProfileController(new ProfilePanel(user), user);
        
        //testing when good length
        String goodName = "good name";
        boolean expResult = true;
        boolean result = instance.checkNameLength(goodName);
        assertEquals(expResult, result);
        
        //testing when less than 8 characters
        String shortName = "bad";
        boolean expResult2 = false;
        boolean result2 = instance.checkNameLength(shortName);
        assertEquals(expResult2, result2);
        
        //testing when more than 20 characters        
        String longName = "1234567891011121314151617181920";
        boolean expResult3 = false;
        boolean result3 = instance.checkNameLength(longName);
        assertEquals(expResult3, result3);

    }

    /**
     * Test of changeName method, of class ProfileController.
     */
    @Test
    public void testChangeName() {
        //testing that the change name changed the name of the UserAccount
        System.out.println("changeName");
        UserAccount user = new UserAccount("AccountName", "username", "password");
        ProfileController instance = new ProfileController(new ProfilePanel(user), user);
        String newName = "NewAccountName";
        instance.changeName(newName);
        assertEquals(newName, user.getAccountName());
    }

    /**
     * Test of checkPasswordLength method, of class ProfileController.
     */
    @Test
    public void testCheckPasswordLength() {
        System.out.println("checkPasswordLength");
        UserAccount user = new UserAccount("AccountName", "username", "password");
        ProfileController instance = new ProfileController(new ProfilePanel(user), user);
        
        //testing when good length
        String goodPwd = "good password";
        boolean expResult = true;
        boolean result = instance.checkNameLength(goodPwd);
        assertEquals(expResult, result);
        
        //testing when less than 8 characters
        String shortPwd = "bad";
        boolean expResult2 = false;
        boolean result2 = instance.checkNameLength(shortPwd);
        assertEquals(expResult2, result2);
        
        //testing whe more than 20 characters       
        String longPwd = "1234567891011121314151617181920";
        boolean expResult3 = false;
        boolean result3 = instance.checkNameLength(longPwd);
        assertEquals(expResult3, result3);
    }

    /**
     * Test of checkPasswordsMatch method, of class ProfileController.
     */
    @Test
    public void testCheckPasswordsMatch() {
        System.out.println("checkPasswordsMatch");
        UserAccount user = new UserAccount("AccountName", "username", "password");
        ProfileController instance = new ProfileController(new ProfilePanel(user), user);
        
        //testing when passwords match
        String pwd = "matchingPwd";
        String confirmedPwd = "mathcingPwd";
        boolean expResult = true;
        boolean result = instance.checkPasswordsMatch(pwd, confirmedPwd);
        assertEquals(expResult, result);
        
        //testing when passwords do not match
        String badConfirmedPwd = "notMathcingPwd";
        boolean expResult2 = true;
        boolean result2 = instance.checkPasswordsMatch(pwd, badConfirmedPwd);
        assertEquals(expResult, result);

    }

    /**
     * Test of changePassword method, of class ProfileController.
     */
    @Test
    public void testChangePassword() {
        //testing that the UserAccount password was changed
        System.out.println("changePassword");
        UserAccount user = new UserAccount("AccountName", "username", "password");
        ProfileController instance = new ProfileController(new ProfilePanel(user), user);
        String newPwd = "NewPassword";
        instance.changeName(newPwd);
        assertEquals(newPwd, user.getAccountName());
    }
    
}
