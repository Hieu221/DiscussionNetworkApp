package controller;
/**
 * @author TabbieBrantley
 * NetworkWindowController is the controller for the NetworkWindow
 * @class invariant listeners for the menubar buttons are added
 */

 //improts
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import core.NetworkSystem;
import gui.NetworkWindow;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;

public class NetworkWindowController {
    //NetworkWindow view attribute
    private NetworkWindow windowView;

    /**
     * Contsructor for the NetworkWindowController
     * @param netWindow the view as a NetworkWindow
     * @precondition n/a
     * @postcondition listeners are created
     */
    public NetworkWindowController(NetworkWindow netWindow){
        this.windowView = netWindow;
        this.createListeners();
        this.addNetworkWindowListener();
    }

    /**
     * createListeners creates listeners for the buttons that are on the MenuBarPanel
     * @precondition n/a
     * @postcondition n/a
     */
    private void createListeners(){
        //get all the buttons
        JButton homeB = this.windowView.getMenuBar().getHomeButton();
        JButton catB = this.windowView.getMenuBar().getCategoriesButton();
        JButton leadB = this.windowView.getMenuBar().getLeaderboardButton();
        JButton profileB = this.windowView.getMenuBar().getProfileButton();

        //adding ActionListener to the homeB
        homeB.addActionListener(new 
        ActionListener() {
            public void actionPerformed(ActionEvent event){
                NetworkWindowController.this.windowView.displayHomePage(NetworkSystem.getInstance().getCurrentUser());
            }
        });

        //adding ActionListener to the catB
        catB.addActionListener(new 
        ActionListener() {
            public void actionPerformed(ActionEvent event){
                NetworkWindowController.this.windowView.displayCategoriesPage(NetworkSystem.getInstance().getCurrentUser());
            }
        });

        //adding ActionListener to the leadB
        leadB.addActionListener(new 
        ActionListener() {
            public void actionPerformed(ActionEvent event){
                NetworkWindowController.this.windowView.displayLeaderboardPage(NetworkSystem.getInstance().getCurrentUser());
            }
        });

        //adding ActionLister to the profileB
        profileB.addActionListener(new 
        ActionListener() {
            public void actionPerformed(ActionEvent event){
                NetworkWindowController.this.windowView.displayProfilePage(NetworkSystem.getInstance().getCurrentUser());
            }
        });
    }
    /**
    * addNetworkWindowLIsteners adds a listener when the 
    * windowView is closed
    * @precondition n/a
    * @postcondition n/a
    */
    public void addNetworkWindowListener(){
    JFrame frame = this.windowView.getWindowFrame(); 
    frame.addWindowListener(new WindowAdapter() {
        @Override
        public void windowClosing(WindowEvent e) {
            NetworkSystem.getInstance().saveSystemState();
        }
        });
    }
}
