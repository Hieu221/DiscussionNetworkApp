/**
 * @author TabbieBrantley 
 * LoginControllerTest file for LoginController class
 */
package controller;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import gui.*;
import core.*;


public class LoginControllerTest {
    
    public LoginControllerTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }


    /**
     * Test of checkCreateLengths method, of class LoginController.
     */
    @Test
    public void testCheckCreateLengths() {
        //checking when they are a good length
        System.out.println("checkCreateLengths");
        String name = "goodlength";
        String username = "goodlength";
        String pwd = "goodlength";
        LoginController instance = new LoginController(new LoginWindow(), 
                new CreateAccountWindow(), NetworkSystem.getInstance());
        boolean expResult = true;
        boolean result = instance.checkCreateLengths(name, username, pwd);
        assertEquals(expResult, result);
        
        //checking when they are more than 8 characters
        String lessName = "less";
        String lessUsername = "lesss";
        String lessPwd = "less";
        boolean expResult2 = false;
        boolean result2 = instance.checkCreateLengths(lessName, lessUsername, lessPwd);
        assertEquals(expResult2, result2);
        
        //chekcing when they are more than 20 characters
        String moreName = "1234567891011121314151617181920";
        String moreUsername = "1234567891011121314151617181920";
        String morePwd = "1234567891011121314151617181920";
        boolean expResult3 = false;
        boolean result3 = instance.checkCreateLengths(moreName, moreUsername, morePwd);
        assertEquals(expResult3, result3);

    }

    /**
     * Test of checkPasswords method, of class LoginController.
     */
    @Test
    public void testCheckPasswords() {
        //checking when the passwords match
        System.out.println("checkPasswords");
        String pwd = "matching";
        String confirmPwd = "matching";
        LoginController instance = new LoginController(new LoginWindow(), new CreateAccountWindow(), NetworkSystem.getInstance());
        boolean expResult = true;
        boolean result = instance.checkPasswords(pwd, confirmPwd);
        assertEquals(expResult, result);
        
        //checking when the passwords do not match
        String badConfirmPwd = "not_matching";
        boolean expResult2 = false;
        boolean result2 = instance.checkPasswords(pwd, badConfirmPwd);
        assertEquals(expResult2, result2);
        
    }   
}