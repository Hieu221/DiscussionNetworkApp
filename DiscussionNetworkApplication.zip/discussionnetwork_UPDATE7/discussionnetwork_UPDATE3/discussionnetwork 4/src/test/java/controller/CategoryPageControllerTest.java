package controller;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import gui.CategoryPage;
/*
 * 
 * @author lewiscox
 * CategoryPageControllertest
 * 
 */
public class CategoryPageControllerTest {

    private CategoryPageController categoryPageController;
    private CategoryPage categoryPage;

    public CategoryPageControllerTest() {
    }

    @BeforeEach
    public void setUp() {
        
        categoryPage = new CategoryPage();
        categoryPageController = new CategoryPageController(categoryPage);
    }

    @AfterEach
    public void tearDown() {
        
    }

    /**
     * Test of updateCategoryPosts method of class CategoryPageController
     */
    @Test
    public void testUpdateCategoryPosts() {
        System.out.println("updateCategoryPosts");

        
        String category = "Sports";
        
        
        categoryPageController.updateCategoryPosts(category);

    }

    /**
     * Test of constructor method, of class CategoryPageController
     */
    @Test
    public void testConstructor() {
        System.out.println("constructor");

        
        assertNotNull(categoryPageController, "CategoryPageController should not be null");
    }

}
