package utility;

import core.NetworkSystem;
import core.Post;
import core.UserPost;
import core.UserAccount;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

/**
 * SortPostStrategyTest tests for SortPostStrategy and its implementations ProfilePageSortStrategy and GeneralPageSortStrategy.
 * @author thuhieu
 */
public class SortPostStrategyTest {

    private NetworkSystem networkSystem;
    private UserAccount currentUser;

    @BeforeEach
    public void setUp() {
        networkSystem = NetworkSystem.getInstance();
        if (networkSystem.getPostsList().isEmpty()){
            networkSystem.addPosts(new UserPost("title1", new UserAccount("name1", "username1", "pass1")));
            networkSystem.addPosts(new UserPost("title2", new UserAccount("name2", "username2", "pass3")));
            networkSystem.addPosts(new UserPost("title3", new UserAccount("name3", "username3", "pass3")));
            networkSystem.addPosts(new UserPost("title4", new UserAccount("name4", "username4", "pass4")));
            
        }
        currentUser = networkSystem.getPostsList().get(0).getOwner();
        networkSystem.setCurrentUser(currentUser);
    }

    /**
     * Test for GeneralPageSortStrategy.
     */
    @Test
    public void testGeneralPageSortStrategy() {
        SortPostStrategy strategy = new GeneralPageSortStrategy();
        ArrayList<Post> sortedPosts = strategy.sortPost();
        Boolean expResult = true;
        Boolean result =true;
        for (int i=0; i<sortedPosts.size()-1; i++){
            if (sortedPosts.get(i).getPostID() <= sortedPosts.get(i+1).getPostID() ){
                result = false;
            }
        }
        assertEquals(result, expResult);
        
    }

    /**
     * Test for ProfilePageSortStrategy.
     */
    @Test
    public void testProfilePageSortStrategy() {
        SortPostStrategy strategy = new ProfilePageSortStrategy();
        
        ArrayList<Post> sortedPosts = strategy.sortPost();
        Boolean expResult = true;
        Boolean result =true;
        for (int i=0; i<sortedPosts.size()-1; i++){
            if (sortedPosts.get(i).getPostID() <= sortedPosts.get(i+1).getPostID() ||
                    (sortedPosts.get(i).getOwner().getUsername().equals(currentUser.getUsername()))){
                result = false;
            }
        }
        assertEquals(result, expResult);
    }
}
