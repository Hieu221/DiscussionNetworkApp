
package gui;

import core.NetworkSystem;
import core.UserAccount;
import core.UserPost;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import utility.GeneralPageSortStrategy;

/**
 * FeedPanelTest tests for class FeedPanel
 * @author Hieu Truong
 */
public class FeedPanelTest {
    private NetworkSystem networkSystem;
    private UserAccount currentUser;
    
    public FeedPanelTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
        
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
        networkSystem = NetworkSystem.getInstance();
        if (networkSystem.getPostsList().isEmpty()){
            networkSystem.addPosts(new UserPost("title1", new UserAccount("name1", "username1", "pass1")));
            networkSystem.addPosts(new UserPost("title2", new UserAccount("name2", "username2", "pass3")));
            networkSystem.addPosts(new UserPost("title3", new UserAccount("name3", "username3", "pass3")));
            networkSystem.addPosts(new UserPost("title4", new UserAccount("name4", "username4", "pass4")));
            
        }
        currentUser = networkSystem.getPostsList().get(0).getOwner();
        networkSystem.setCurrentUser(currentUser);
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of displayFeed method, of class FeedPanel.
     */
    @Test
    public void testDisplayFeed() {
        System.out.println("displayFeed");
        FeedPanel instance = new FeedPanel(new GeneralPageSortStrategy()); 
        assertNotNull(instance);
        
    }
    
}
