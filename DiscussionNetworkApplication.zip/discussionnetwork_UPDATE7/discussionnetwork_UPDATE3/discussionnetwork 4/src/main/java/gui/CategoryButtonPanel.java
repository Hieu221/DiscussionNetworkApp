package gui;

import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;


/**
 * @author  Lewis Cox
 * CategoryButtonPanel contains buttons for each category allowing users to filter posts
 * by category 
 * 
 */
public class CategoryButtonPanel extends JPanel {

    /**
     * constructs the CategoryButtonPanel 
     */
    public CategoryButtonPanel() {
        this.setLayout(new FlowLayout());

        // create buttons for each category
        String[] categories = {"Sports", "Technology", "Art", "News"};

        for (String category : categories) {
            JButton categoryButton = new JButton(category);
            categoryButton.addActionListener(new CategoryButtonListener(category));
            this.add(categoryButton);
        }
    }

    /**
     * updates the CategoryPage with the selected category
     */
    private class CategoryButtonListener implements ActionListener {
        private String category;

        /**
         * constructs a listener for a specific category button
         * 
         * @param category category that the button represents
         */
        public CategoryButtonListener(String category) {
            this.category = category;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            
            CategoryPage categoryPage = (CategoryPage) SwingUtilities.getAncestorOfClass(CategoryPage.class, (Component) e.getSource());
            if (categoryPage != null) {
                categoryPage.updateCategoryPosts(category);
            }
        }
    }
}