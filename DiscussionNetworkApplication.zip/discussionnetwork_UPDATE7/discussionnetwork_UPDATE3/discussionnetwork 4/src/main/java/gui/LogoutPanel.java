package gui;
/**
 * @author Tabbie Brantley
 * LogoutPanel extends JPanel
 * @class invariant the logoutButton is shown
 */

//imports
import java.awt.*;
import javax.swing.*;

public class LogoutPanel extends JPanel{
    private JButton logoutButton; 
    private GridBagConstraints c;
    
    /**
    * Constructor for LogoutPanel
    * @precondition n/a
    * @postcondition n/a
    */
    public LogoutPanel(){
        this.logoutButton = new JButton("Logout");

        this.c = new GridBagConstraints();
        this.c.fill = GridBagConstraints.HORIZONTAL;
        this.c.insets = new Insets(5, 5, 5,  5);

        this.setLayout(new GridBagLayout());
        this.c.gridx = 0;
        this.c.gridy = 0;
        this.add(this.logoutButton, this.c);
    }

    /**
     * Accessor for logoutButton
     * @return this.logoutButton as JButton
     * @precondition n/a
     * @postcondition n/a
     */
    public JButton getLogoutButton(){
        return this.logoutButton;
    }
}
