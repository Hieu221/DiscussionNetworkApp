package gui;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import core.NetworkSystem;
import core.Post;
import core.UserPost;

/**
 * NewPostCreatePanel is a JPanel for creating a new post
 * Allowing users to input content, select a category, and save or cancel the operation.
 * Includes interactive features such as placeholder text, category selection, and focus behavior.
 * @author Hieu
 */
public class NewPostCreatePanel extends JPanel {
    private JTextArea content;
    private final JButton save;
    private final JButton cancel;
    private JMenu categoryMenu;
    private final JMenuBar menuBar;
    private final JMenuItem[] menuItem;
    private final String ENTER_COMMAND = "Enter your opinion here";
    ArrayList<String> categoryName = new ArrayList<>(Arrays.asList("Sports", "Technology", "Art", "News"));

    /**
     * Constructs a NewPostCreatePanel with text input, category selection, and save/cancel buttons.
     * @precondition: Requires the action on the JTextArea and the JButton
     * @postcondition: If "Save" is clicked, a new post is added to the system's network and the profile feed is refreshed.
     */
    public NewPostCreatePanel() {
        this.setLayout(new BorderLayout());

        JLabel label = new JLabel("Write a new post");
        this.add(label, BorderLayout.NORTH);

        //set text area with placeholder text
        content = new JTextArea(ENTER_COMMAND);
        content.setForeground(Color.LIGHT_GRAY);
        content.setBorder(new EmptyBorder(10, 10, 10, 10));
        content.setLineWrap(true);
        content.setWrapStyleWord(true);
        content.setRows(1);

        content.addFocusListener(new FocusListener() {
            //Clears placeholder text when the text area gains focus.
            @Override
            public void focusGained(FocusEvent e) {
                if (content.getText().equals(ENTER_COMMAND)) {
                    content.setText("");
                    content.setForeground(Color.BLACK);
                }
            }

            //Restores placeholder text if the text area loses focus with no input.
            @Override
            public void focusLost(FocusEvent e) {
                if (content.getText().equals("")) {
                    content.setText(ENTER_COMMAND);
                    content.setForeground(Color.LIGHT_GRAY);
                }
            }
        });
        this.add(content, BorderLayout.CENTER);

        //set the action panel, which contains the buttons
        JPanel actionPanel = new JPanel();

        //save button to create and save a new post
        save = new JButton("Save");
        save.addActionListener(new ActionListener() {
            //saves the post content and category into the network system.
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!content.getText().equals("") && !content.getText().equals(ENTER_COMMAND)) {
                    String contentString = content.getText();
                    Post newPost = new UserPost(contentString, NetworkSystem.getInstance().getCurrentUser());
                    if (!categoryMenu.getText().equals("Category")) {
                        newPost.setCategory(categoryMenu.getText());
                    }
                    NetworkSystem.getInstance().addPosts(newPost);
                    NetworkSystem.getInstance().getNetworkWindow().getProfilePagePanel().refreshProfileFeed();
                }
            }
        });

        //cancel button to clear the input field
        cancel = new JButton("Cancel");
        cancel.addActionListener(new ActionListener() {
            //Clears the text area input. 
            @Override
            public void actionPerformed(ActionEvent e) {
                content.setText("");
            }
        });

        //initialize category menu
        menuItem = new JMenuItem[categoryName.size()];
        menuBar = new JMenuBar();
        categoryMenu = new JMenu("Category");

        for (int i = 0; i < categoryName.size(); i++) {
            menuItem[i] = new JMenuItem(categoryName.get(i));
            final String name = categoryName.get(i);
            menuItem[i].addActionListener(e -> categoryMenu.setText(name));
            categoryMenu.add(menuItem[i]);
        }
        menuBar.add(categoryMenu);

        // Set up action panel
        actionPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        actionPanel.add(menuBar);
        actionPanel.add(save);
        actionPanel.add(cancel);

        this.setBorder(BorderFactory.createLineBorder(Color.WHITE, 15));
        this.add(actionPanel, BorderLayout.SOUTH);
    }
}
