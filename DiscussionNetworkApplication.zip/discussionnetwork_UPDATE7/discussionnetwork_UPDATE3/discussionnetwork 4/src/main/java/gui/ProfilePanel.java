package gui;
/**
 * @author Tabbie Brantley
 * The ProfileView class is the view for the Profile
 * @class invariant the view will always show the current UserAccount name
 */

//imports
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import core.UserAccount;


public class ProfilePanel extends JPanel{
    
    //attributes for main profilePanel
    private JPanel userInfoPanel;
    private JLabel currentNameLabel;
    private JLabel currentPointsLabel;
    private UserAccount user;
    private JButton editNameButton;
    private JButton editPasswordButton;

    //attributes for editNameFrame
    private JFrame editNameFrame;
    private JPanel editNamePanel;
    private JButton saveNameButton;
    private JLabel enterNameLabel;
    private JTextField nameField;
    private JButton cancelNameEditButton;
    
    //attributes for editPassword frame
    private JFrame editPasswordFrame;
    private JPanel editPasswordPanel;
    private JButton savePasswordButton;
    private JLabel enterPasswordLabel;
    private JLabel confirmPasswordLabel;
    private JTextField passwordField;
    private JTextField reentryPasswordField;
    private JButton cancelPasswordEditButton; 


    private GridBagConstraints c;

    /**
     * Constructor for profile panel
     * @param curUser the current user as a UserAccount
     * @precondtion n/a
     * @postcondition view is shown
     */
    public ProfilePanel(UserAccount curUser){
        this.user = curUser;
        
        //setting c info
        this.c = new GridBagConstraints();
        this.c.fill = GridBagConstraints.HORIZONTAL;
        this.c.insets = new Insets(5, 5, 5,  5);

        //initializing the profilePanel
        this.setLayout(new BorderLayout());

        //initializing the userInfoPanel
        this.userInfoPanel = new JPanel();
        this.userInfoPanel.setLayout(new GridBagLayout());
        this.currentNameLabel = new JLabel("Account Name: " + user.getAccountName());
        this.currentPointsLabel = new JLabel("Total Points: " + Integer.toString(user.getPoints()));

        //adding labels and buttons
        this.c.gridx = 0;
        this.c.gridy = 0;
        this.userInfoPanel.add(this.currentNameLabel, this.c);

        this.c.gridx = 0;
        this.c.gridy = 1;
        this.userInfoPanel.add(this.currentPointsLabel, this.c);

        this.editNameButton = new JButton("Edit name");
        this.editPasswordButton = new JButton("Edit password");

        this.c.gridx = 0;
        this.c.gridy = 2;
        this.userInfoPanel.add(this.editNameButton, this.c);

        this.c.gridx = 0;
        this.c.gridy = 3;
        this.userInfoPanel.add(this.editPasswordButton, this.c);

        this.add(userInfoPanel, BorderLayout.WEST);

        //setting up the editNameFrame
        this.editNameFrame = new JFrame();
        this.editNamePanel = new JPanel();
        this.editNamePanel.setLayout(new GridBagLayout());

        this.enterNameLabel = new JLabel("Enter new name:");
        this.nameField = new JTextField();
        this.saveNameButton = new JButton("Save Name");
        this.cancelNameEditButton = new JButton("Cancel");

        this.c.gridx = 0;
        this.c.gridy = 0;
        this.editNamePanel.add(this.enterNameLabel, this.c);

        this.c.gridx = 1;
        this.c.gridy = 0;
        this.editNamePanel.add(this.nameField, this.c);

        this.c.gridx = 0;
        this.c.gridy = 1;
        this.editNamePanel.add(this.saveNameButton, this.c);

        this.c.gridx = 1;
        this.c.gridy = 1;
        this.editNamePanel.add(this.cancelNameEditButton, this.c);

        this.editNameFrame.add(this.editNamePanel);
        this.editNameFrame.pack();

        //setting up the editPasswordFrame
        this.editPasswordFrame = new JFrame();
        this.editPasswordPanel = new JPanel();
        this.editPasswordPanel.setLayout(new GridBagLayout());

        this.enterPasswordLabel = new JLabel("Enter New Password:");
        this.confirmPasswordLabel = new JLabel("Confirm Password:");
        this.savePasswordButton = new JButton("Save Password");
        this.passwordField = new JTextField();
        this.reentryPasswordField = new JTextField();
        this.cancelPasswordEditButton = new JButton("Cancel"); 


        this.c.gridx = 0;
        this.c.gridy = 0;
        this.editPasswordPanel.add(this.enterPasswordLabel, this.c);

        this.c.gridx = 1;
        this.c.gridy = 0;
        this.editPasswordPanel.add(this.passwordField, this.c);

        this.c.gridx = 0;
        this.c.gridy = 1;
        this.editPasswordPanel.add(this.confirmPasswordLabel, this.c);

        this.c.gridx = 1;
        this.c.gridy = 1;
        this.editPasswordPanel.add(this.reentryPasswordField, this.c);

        this.c.gridx = 0;
        this.c.gridy = 2;
        this.editPasswordPanel.add(this.savePasswordButton, this.c);

        this.c.gridx = 1;
        this.c.gridy = 2;
        this.editPasswordPanel.add(this.cancelPasswordEditButton, this.c);

        this.editPasswordFrame.add(this.editPasswordPanel);
        this.editPasswordFrame.pack();
    }

    /**
     * getProfilePanel accessor for the profile panel
     * @return the profilePanels reference
     * @precondition n/a
     * @postcondition n/a
     */
    public JPanel getProfilePanel(){
        return this;
    }

    /**
     * getEditNameButton accessor for the editNameButton
     * @return the editNameButton reference
     * @precondition n/a
     * @postcondition n/a
     */
    public JButton getEditNameButton(){
        return this.editNameButton;
    }

     /**
     * getCancelNameButton accessor for the cancelNameButton
     * @return the cancelNameButton reference
     * @precondition n/a
     * @postcondition n/a
     */
    public JButton getCancelNameButton(){
        return this.cancelNameEditButton;
    }

     /**
     * getSaveNameButton accessor for the saveNameButton
     * @return the saveNameButton reference
     * @precondition n/a
     * @postcondition n/a
     */
    public JButton getSaveNameButton(){
        return this.saveNameButton;
    }

    /**
     * getNewName accessor for the nameField
     * @return the nameField reference
     * @precondition n/a
     * @postcondition n/a
     */
    public JTextField getNewName(){
        return this.nameField;
    }

    /**
     * getEditPasswordButton accessor for the editPasswordButton
     * @return the editPasswordButton reference
     * @precondition n/a
     * @postcondition n/a
     */
    public JButton getEditPasswordButton(){
        return this.editPasswordButton;
    }

    /**
     * getCancelPasswordButton accessor for the cancelPasswordButton
     * @return the cancelPasswordButton reference
     * @precondition n/a
     * @postcondition n/a
     */
    public JButton getCancelPasswordEditButton(){
        return this.cancelPasswordEditButton;
    }

    /**
     * getSavePasswordButton accessor for the savePasswordButton
     * @return the savePasswordButton reference
     * @precondition n/a
     * @postcondition n/a
     */
    public JButton getSavePasswordButton(){
        return this.savePasswordButton;
    }


    /**
     * getNewPassword accessor for the passwordField
     * @return the passwordField reference
     * @precondition n/a
     * @postcondition n/a
     */    
    public JTextField getNewPassword(){
        return this.passwordField;
    }

    /**
     * getConfirmedPassword accessor for the reentryPasswordField
     * @return the reentryPasswordField reference
     * @precondition n/a
     * @postcondition n/a
     */    
    public JTextField getConfirmedPassword(){
        return this.reentryPasswordField;
    }

    /**
     * editName to display the edit name frame
     * @precodition n/a
     * @postcodntion editNameFrame is set to be visible
     */
    public void editName(){
        this.editNameFrame.setVisible(true);
    }

    /**
     * cancelName to stop displaying the editNameFrame
     * @precodition n/a
     * @postcodntion editNameFrame is set to not be visible
     */
    public void cancelNameEdit(){
        this.editNameFrame.setVisible(false);
    }

    /**
     * displayNameLengthErrorMessage displays a JOptionPane with the 
     * corresponding error
     * @procondion n/a
     * @postcondition n/a
     */
    public void displayNameLengthErrorMessage(){
        JOptionPane.showMessageDialog(null, "Error: Name must be between 8-20 characters.");
    }

    /**
     * closeEditName closes the editName frame
     * @precodition n/a
     * @postcodntion editNameFrame is set to not be visible
     */
    public void closeEditName(){
        this.editNameFrame.setVisible(false);
    }

    /**
     * editPassowrd to display the edit name frame
     * @precodition n/a
     * @postcodntion editPasswordFrame is set to be visible
     */
    public void editPassword(){
        this.editPasswordFrame.setVisible(true);
    }

    /**
     * cancelPasswordEdit to stop displaying the editPasswordFrame
     * @precodition n/a
     * @postcodntion editNameFrame is set to not be visible
     */
    public void cancelPasswordEdit(){
        this.editPasswordFrame.setVisible(false);
    }

    
    /**
     * displayPasswordLengthErrorMessage displays a JOptionPane with the 
     * corresponding error
     * @procondion n/a
     * @postcondition n/a
     */
    public void displayPasswordLengthErrorMessage(){
        JOptionPane.showMessageDialog(null, "Error: Password must be between 8-20 characters.");
    }

    /**
     * displayPasswordMatchErrorMessage displays a JOptionPane with the 
     * corresponding error
     * @procondion n/a
     * @postcondition n/a
     */
    public void displayPasswordMatchErrorMessage(){
        JOptionPane.showMessageDialog(null, "Error: Passwords do not match.");
    }

     /**
     * closeEditPassword closes the editPassword frame
     * @precodition n/a
     * @postcodntion editNameFrame is set to not be visible
     */
    public void closeEditPassword(){
        this.editPasswordFrame.setVisible(false);
    }   

    /**
     * updateName sets the currentNameLabel text to a new name
     * @param nm is the new name as a String
     * @precondtion n/a
     * @postcondition the current instance of ProfilePanel is repainted to display
     * the new name
     */
    public void updateName(String nm){
        this.currentNameLabel.setText("Account Name: " + nm);
        this.repaint();
    }

    /**
     * Update the point label
     * @precondtion n/a
     * @postcondition the current instance (currentPointsLabel) of ProfilePanel is repainted to display
     */
    public void updatePointLabel(){
        this.currentPointsLabel.setText("Total Points: " + Integer.toString(user.getPoints()));
        this.repaint();
        System.out.println("Update point");
    }
}