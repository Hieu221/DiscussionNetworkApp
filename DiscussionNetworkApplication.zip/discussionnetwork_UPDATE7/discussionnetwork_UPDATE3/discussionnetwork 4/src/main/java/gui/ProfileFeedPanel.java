package gui;

import java.awt.BorderLayout;

import javax.swing.JPanel;

import utility.ProfilePageSortStrategy;

/**
 * ProfileFeedPanel is a JPanel that displays the user's profile feed, including a post creation section
 * at the top and a feed panel that displays posts sorted based on a profile page strategy.
 * @author Tabbie, Hieu
 */
public class ProfileFeedPanel extends JPanel {
    private NewPostCreatePanel createPostPanel; 
    private FeedPanel feedPanel;  

    /**
     * Constructs a ProfileFeedPanel that initializes the components.
     * The panel contains a NewPostCreatePanel at the top and a FeedPanel in the center, sorted using ProfilePageSortStrategy.
     * The layout is set to BorderLayout, and the components are added accordingly.
     * A ProfileFeedPanel is created with a NewPostCreatePanel at the top and a FeedPanel in the center
     */
    public ProfileFeedPanel() {
        this.createPostPanel = new NewPostCreatePanel();
        this.feedPanel = new FeedPanel(new ProfilePageSortStrategy());
        this.setLayout(new BorderLayout());
        this.add(this.createPostPanel, BorderLayout.NORTH);
        this.add(this.feedPanel, BorderLayout.CENTER);
    }

    /**
     * Refreshes the feed panel by repainting it.
     * Used to update the feed display after a new post has been created or the feed has changed.
     * @precondition A ProfileFeedPanel has already been initialized with a FeedPanel.
     * @postcondition The feed panel is repainted to reflect any changes.
     * @return The current instance of ProfileFeedPanel.
     */
    public ProfileFeedPanel createProfileFeedPanel() {
        this.feedPanel.repaint();
        return this;
    }
}
