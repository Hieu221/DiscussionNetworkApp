package gui;
/**
 * @auther Tabbie Brantley
 * MenuBarPanel extends JPanel and displays the menu buttons
 * @class invariant buttons are added
 */

//import
import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JPanel;

public class MenuBarPanel extends JPanel {
    private JButton homeButton;
    private JButton categoriesButton;
    private JButton leaderboardButton;
    private JButton profileButton;

    /**
     * Constructor for MenuBarPanel
     * @precondition n/a
     * @postcondition n/a
     */
    public MenuBarPanel(){
        this.setLayout(new GridLayout(1, 4));
        this.setBackground(new Color(219, 231, 252));
        this.homeButton = new JButton("Home");
        this.categoriesButton = new JButton("Categories");
        this.leaderboardButton = new JButton("Leaderboard");
        this.profileButton = new JButton("Profile");

        this.add(this.homeButton);
        this.add(this.categoriesButton);
        this.add(this.leaderboardButton);
        this.add(this.profileButton);    
        
    }

    /**
     * Accessor for this.homeButton
     * @return this.homeButton as a JButton
     * @precondition n/a
     * @postcondition n/a
     */
    public JButton getHomeButton(){
        return this.homeButton;
    }

    /**
     * Accessor for this.homeButton
     * @return this.homeButton as a JButton
     * @precondition n/a
     * @postcondition n/a
     */
    public JButton getCategoriesButton(){
        return this.categoriesButton;
    }

    /**
     * Accessor for this.leaderboardButton
     * @return this.leaderboardButton as a JButton
     * @precondition n/a
     * @postcondition n/a
     */
    public JButton getLeaderboardButton(){
        return this.leaderboardButton;
    }

    /**
     * Accessor for this.profileButton
     * @return this.profileButton as a JButton
     * @precondition n/a
     * @postcondition n/a
     */
    public JButton getProfileButton(){
        return this.profileButton;
    }

    /**
     * Accessor for this current instance of MenuBarPanel
     * @return this as a MenuBarPanel
     * @precondition n/a
     * @postcondition n/a
     */
    public MenuBarPanel getMenuBarPanel(){
        return this;
    }
}
