package gui;
/**
 * @author Selin Topac
 * loginWindow window view for signing in
 * @class invariant.......
 */


//imports
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class LoginWindow {
    //frame and panel
    private JFrame loginFrame;
    private JPanel loginPanel;

    //buttons
    private JButton loginButton;
    private JButton CreateAccountButton;

    //labels
    private JLabel instructionsLabel;
    private JLabel usernameLabel;
    private JLabel passwordLabel;

    //JTextFields and JTextField arra
    private JTextField[] textFields = new JTextField[2];
    private JTextField usernameTextField;
    private JTextField passwordTextField;

    //GridBagConstraint
    private GridBagConstraints c;

    /**
     * Constructor for loginWindow
          * @return 
          * @precondition n/a
          * @postcondition JFrame window is created and is set to be visible 
          */
        public LoginWindow(){

        //creating JFrame and JPanel with JPanel has GridBagLayout
        this.loginFrame = new JFrame();
        this.loginFrame.setLayout(new BorderLayout());
        this.loginPanel = new JPanel();
        this.loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //creating instructions label
        this.instructionsLabel = new JLabel("Enter your username and password. If you do not have an account, click Create Account");
        this.instructionsLabel.setBorder(new EmptyBorder(200, 300, 0, 200));

        //creating create account panel
        this.loginPanel.setLayout(new GridBagLayout());
        this.c = new GridBagConstraints();
        this.c.fill = GridBagConstraints.HORIZONTAL;
        this.c.insets = new Insets(5, 5, 5,  5);
        
        //Creating labels
        this.usernameLabel = new JLabel("Enter a username:");
        this.passwordLabel = new JLabel("Enter a password:");

        //Createing text fields
        this.usernameTextField  = new JTextField(40);
        this.passwordTextField = new JTextField(40);
        this.textFields[0] = this.usernameTextField;
        this.textFields[1] = this.passwordTextField;

        //creating buttons
        this.loginButton = new JButton("Login");
        this.CreateAccountButton = new JButton("Create an Account");

        //adding labels, text fields, and buttons to the panel

        this.c.gridx = 0;
        this.c.gridy = 1;
        this.loginPanel.add(this.usernameLabel, this.c);

        this.c.gridx = 1;
        this.c.gridy = 1;
        this.loginPanel.add(this.usernameTextField, this.c);

        this.c.gridx = 0;
        this.c.gridy = 2;
        this.loginPanel.add(this.passwordLabel, this.c);

        this.c.gridx = 1;
        this.c.gridy = 2;
        this.loginPanel.add(this.passwordTextField, this.c);

        this.c.gridx = 0;
        this.c.gridy = 4;
        this.loginPanel.add(this.CreateAccountButton, this.c);
        
        this.c.gridx = 1;
        this.c.gridy = 4;
        this.loginPanel.add(this.loginButton, this.c);

        //adding panel to frame, and setting frame to MAXIMIZED_BOTH, and setting visible true to pane
        this.loginFrame.add(this.instructionsLabel, BorderLayout.NORTH);
        this.loginFrame.add(loginPanel, BorderLayout.CENTER);
        this.loginFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);           
        this.loginFrame.setVisible(true);       
    }



    /**
     * Getter for loginButton
     * @return loginButton as JButton
     * @precondition n/a
     * @postcondition n/a
     */
    public JButton getLoginButton(){
        return this.loginButton;
    }

    /**
     * Getter for eturnToLoginButton
     * @return eturnToLoginButton as JButton
     * @precondition n/a
     * @postcondition n/a
     */
    public JButton getCreateAccountButton(){
        return this.CreateAccountButton;
    }

    /**
     * Getter for the textFields
     * @return textFields as JTextField[]
     * @precondition n/a
     * @postcondition the reference of the textfields is not returned, only a copy
     */
    public JTextField[] getJTextFields() {
        return this.textFields.clone();
    }

    /**
     * openLoginWindow to open the window
     * @precondition n/a
     * @postcondition loginFrame is visible
     */
    public void openLoginWindow(){
        this.loginFrame.setVisible(true);
    }

    /**
     * closeloginWindow to close the window
     * @precondition n/a
     * @postcondition loginFrame is no longer visible
     */
    public void closeLoginWindow(){
        this.loginFrame.setVisible(false);
    }

    /**
     * displayLengthConstraintMessage displays message for constraint in a JOptionPane
     * @precondition n/a
     * @postcondition n/a
     */
    public void displayLengthConstraintMessage(){
        JOptionPane.showMessageDialog(this.loginFrame, "Error: Username and password must be between 8-20 characters.");
    }

    /**
     * displayUsernameNotExistMessage displays message in a JOptionPane
     * @precondition n/a
     * @postcondition n/a
     */
    public void displayUsernameNotExistMessage(){
        JOptionPane.showMessageDialog(this.loginFrame, "Error: Username does not exist.");
    }

   /**
     * displayPasswordIsNotCorrectMessage in a JOptionPane
     * @precondition n/a
     * @postcondition n/a
     */
    public void displayPasswordIsNotCorrectMessage(){
        JOptionPane.showMessageDialog(this.loginFrame, "Password is not correct.");
    }
    
    /**
     * Accessor for loginFrane
     * @return this.loginFrame as a JFrame
     * @precondition n/a
     * @postcondition n/a
     */
    public JFrame getLoginWindow(){
        return this.loginFrame;
    }
    
}