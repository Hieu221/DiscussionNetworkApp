package gui;
/**
 * @author Tabbie Brantley
 * CreateAccountWindow window view for creating an account
 * @class invariant.......
 */


//imports
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class CreateAccountWindow {
    //frame and panel
    private JFrame createAccountFrame;
    private JPanel createAccountPanel;

    //buttons
    private JButton createAccountButton;
    private JButton returnToLoginButton;

    //labels
    private JLabel instructionsLabel;
    private JLabel accountNameLabel;
    private JLabel usernameLabel;
    private JLabel passwordLabel;
    private JLabel confirmPasswordLabel;

    //JTextFields and JTextField arra
    private JTextField[] textFields = new JTextField[4];
    private JTextField accountNameTextField;
    private JTextField usernameTextField;
    private JTextField passwordTextField;
    private JTextField confirmPasswordTextField;

    //GridBagConstraint
    private GridBagConstraints c;

    /**
     * Constructor for CreateAccountWindow
     * @precondition n/a
     * @postcondition JFrame window is created and is set to be visible 
     */
    public CreateAccountWindow(){

        //creating JFrame and JPanel with JPanel has GridBagLayout
        this.createAccountFrame = new JFrame();
        this.createAccountFrame.setLayout(new BorderLayout());
        this.createAccountPanel = new JPanel();
        this.createAccountFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //creating instructions label
        this.instructionsLabel = new JLabel("Enter in new account information. Press Create Account when done and you will be brought"
        + " back to the login page. Press Return to Login if you do not wish to create a new account.");
        this.instructionsLabel.setBorder(new EmptyBorder(200, 300, 0, 200));

        //creating create account panel
        this.createAccountPanel.setLayout(new GridBagLayout());
        this.c = new GridBagConstraints();
        this.c.fill = GridBagConstraints.HORIZONTAL;
        this.c.insets = new Insets(5, 5, 5,  5);
        
        //Creating labels
        this.accountNameLabel = new JLabel("Enter an account name:");
        this.usernameLabel = new JLabel("Enter a username:");
        this.passwordLabel = new JLabel("Enter a password:");
        this.confirmPasswordLabel = new JLabel("Confirm password:");

        //Createing text fields
        this.accountNameTextField = new JTextField(20);
        this.usernameTextField  = new JTextField(40);
        this.passwordTextField = new JTextField(40);
        this.confirmPasswordTextField = new JTextField(40);
        this.textFields[0] = this.accountNameTextField;
        this.textFields[1] = this.usernameTextField;
        this.textFields[2] = this.passwordTextField;
        this.textFields[3] = this.confirmPasswordTextField;

        //creating buttons
        this.createAccountButton = new JButton("Create Account");
        this.returnToLoginButton = new JButton("Return to Login");

        //adding labels, text fields, and buttons to the panel
        this.c.gridx = 0;
        this.c.gridy = 0;
        this.createAccountPanel.add(this.accountNameLabel, this.c);

        this.c.gridx = 1;
        this.c.gridy = 0;
        this.createAccountPanel.add(this.accountNameTextField, this.c);

        this.c.gridx = 0;
        this.c.gridy = 1;
        this.createAccountPanel.add(this.usernameLabel, this.c);

        this.c.gridx = 1;
        this.c.gridy = 1;
        this.createAccountPanel.add(this.usernameTextField, this.c);

        this.c.gridx = 0;
        this.c.gridy = 2;
        this.createAccountPanel.add(this.passwordLabel, this.c);

        this.c.gridx = 1;
        this.c.gridy = 2;
        this.createAccountPanel.add(this.passwordTextField, this.c);

        this.c.gridx = 0;
        this.c.gridy = 3;
        this.createAccountPanel.add(this.confirmPasswordLabel, this.c);

        this.c.gridx = 1;
        this.c.gridy = 3;
        this.createAccountPanel.add(this.confirmPasswordTextField, this.c);

        this.c.gridx = 0;
        this.c.gridy = 4;
        this.createAccountPanel.add(this.returnToLoginButton, this.c);
        
        this.c.gridx = 1;
        this.c.gridy = 4;
        this.createAccountPanel.add(this.createAccountButton, this.c);

        //adding panel to frame, and setting frame to MAXIMIZED_BOTH, and setting visible true to pane
        this.createAccountFrame.add(this.instructionsLabel, BorderLayout.NORTH);
        this.createAccountFrame.add(createAccountPanel, BorderLayout.CENTER);
        this.createAccountFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);           
        //this.createAccountFrame.setVisible(true);       
    }

    /**
     * Getter for createAccountButton
     * @return createAccountBUtton as JButton
     * @precondition n/a
     * @postcondition n/a
     */
    public JButton getCreateAccountButton(){
        return this.createAccountButton;
    }

    /**
     * Getter for eturnToLoginButton
     * @return eturnToLoginButton as JButton
     * @precondition n/a
     * @postcondition n/a
     */
    public JButton getReturnToLoginButton(){
        return this.returnToLoginButton;
    }

    /**
     * Getter for the textFields
     * @return textFields as JTextField[]
     * @precondition n/a
     * @postcondition the reference of the textfields is not returned, only a copy
     */
    public JTextField[] getJTextFields() {
        return this.textFields.clone();
    }

    /**
     * openCreateAccountWindow toopen the window
     * @precondition n/a
     * @postcondition createAccountFrame is visible
     */
    public void openCreateAccountWindow(){
        this.createAccountFrame.setVisible(true);
    }

    /**
     * closeCreateAccountWindow to close the window
     * @precondition n/a
     * @postcondition createAccountFrame is no longer visible
     */
    public void closeCreateAccountWindow(){
        this.createAccountFrame.setVisible(false);
    }

    /**
     * displayLengthConstraintMessage displays message for constraint in a JOptionPane
     * @precondition n/a
     * @postcondition n/a
     */
    public void displayLengthConstraintMessage(){
        JOptionPane.showMessageDialog(this.createAccountFrame, "Error: Account Name, Username, and password must be between 8-20 characters.");
    }

   /**
     * displayPasswordNotMatchMessage displays message for unmatching passwords in a JOptionPane
     * @precondition n/a
     * @postcondition n/a
     */
    public void displayPasswordNotMatchMessage(){
        JOptionPane.showMessageDialog(this.createAccountFrame, "Error: Passwords do not match.");
    }
    
    /**
     * displayAccountNameAlreadyUsedMessage displays message for a username already in use in a JOptionPane
     * @precondition n/a
     * @postcondition n/a
     */
    public void displayAccountNameAlreadyUsedMessage(){
        JOptionPane.showMessageDialog(this.createAccountFrame, "Error: Username has already been used. Enter a different "
        + "username.");
    }
    
    /**
     * Accessor for the createAccountFrame
     * @return this.createAccountFrame as a JFrame
     * @precondition n/a
     * @postcondition n/a
     */
    public JFrame getCreateAccountFrame(){
        return this.createAccountFrame;
    }
}