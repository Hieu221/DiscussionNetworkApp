package gui;


import java.awt.Color;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JPanel;

import utility.SortPostStrategy;
import core.Post;

/**
 * The FeedPanel class represents a panel for displaying a feed of posts.
 * It dynamically populates itself based on the sorting strategy provided.
 * The feed is displayed as a vertical list of posts.
 * @author Hieu Truong
 */
public class FeedPanel extends JPanel {
    private SortPostStrategy sortStrategy;
    private ArrayList<Post> posts;

    /**
     * Constructs a FeedPanel object using the specified sorting strategy.
     * This constructor initializes the feed by sorting posts and displaying them.
     *
     * @param strategy the sorting strategy used to determine the order of posts.
     * @throws IllegalArgumentException if the strategy is null
     * @precondition strategy != null: A valid sorting strategy must be provided.
     * @postcondition The panel is initialized with posts sorted according to the given strategy.
     */
    public FeedPanel(SortPostStrategy strategy) {
        if (strategy == null) {
            throw new IllegalArgumentException("Sorting strategy cannot be null.");
        }
        sortStrategy = strategy;
        posts = strategy.sortPost();
        this.displayFeed();
        this.repaint();
    }

    /**
     * Displays the feed by adding the sorted posts to the panel in a vertical layout.
     * Each post is represented as a complete post panel, rendered in the order specified by the sorting strategy.
     *
     * @return the current instance of FeedPanel for method chaining.
     * @pre posts != null && !posts.isEmpty(): Posts must be initialized and non-empty.
     * @post The feed panel is populated with all posts in the correct order.
     */
    public final FeedPanel displayFeed() {
        this.setBackground(Color.WHITE);
        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        System.out.println("Display profile feed posts");
        for (int i = 0; i < posts.size(); i++) {
            this.add(posts.get(i).getCompletePostPanel(sortStrategy));
            System.out.println(posts.get(i));
        }
        return this;
    }
}

