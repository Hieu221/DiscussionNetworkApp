package gui;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;

import controller.LogoutController;
import controller.ProfileController;
import core.NetworkSystem;
import core.UserAccount;

/**
 * ProfilePagePanel represents the panel in profile page.
 * It includes a profile panel showing user details (west), a feed panel displaying posts(center), 
 * and a logout panel(east) with functionality to log out of the system. 
 * @author Tabbie, Hieu
 */
public class ProfilePagePanel extends JPanel {

    private ProfilePanel profilePanel;
    private ProfileFeedPanel profileFeedPanel;
    private final LogoutPanel logoutPanel;
    private JScrollPane scrollPane;

    /**
     * Constructs a ProfilePagePanel.
     * Set up the profile panel, profile feed panel, and logout panel, and their controller
     * @precondition The current user is retrieved from the NetworkSystem.
     * @postcondition A ProfilePagePanel is created with all necessary components, 
     *                including the profile, feed, and logout panels, 
     *                and their respective controllers.
     */
    public ProfilePagePanel() {
        UserAccount curUser = NetworkSystem.getInstance().getCurrentUser();
        this.profilePanel = new ProfilePanel(curUser);
        this.profileFeedPanel = new ProfileFeedPanel();
        this.logoutPanel = new LogoutPanel();

        //set the width and color for the west and east panel
        int panelWidth = NetworkSystem.getInstance().getWidth() / 5; 
        this.profilePanel.setPreferredSize(new Dimension(panelWidth, this.getHeight())); 
        this.logoutPanel.setPreferredSize(new Dimension(panelWidth, this.getHeight())); 

        this.profileFeedPanel.setBackground(new Color(219, 231, 252));
        this.logoutPanel.setBackground(new Color(219, 231, 252));

        LogoutController logoutController = new LogoutController(this.logoutPanel, NetworkSystem.getInstance());
        ProfileController profileController = new ProfileController(profilePanel, curUser);

        this.setLayout(new BorderLayout());

        this.add(this.profilePanel, BorderLayout.WEST);
        this.add(this.logoutPanel, BorderLayout.EAST);
        setScrollPane();
        this.add(scrollPane, BorderLayout.CENTER);
    }

    /**
     * Wraps the profile feed panel in a scroll pane to make the feed scrollable.
     * The scroll pane's vertical scroll bar is set to always be visible.
     * @precondition The profile feed panel is initialized.
     * @postcondition A JScrollPane containing the profile feed panel is set, 
     *                and the vertical scroll bar is made visible.
     */
    public final void setScrollPane() {
        scrollPane = new JScrollPane(this.profileFeedPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.getVerticalScrollBar().setValue(0);
        SwingUtilities.invokeLater(() -> scrollPane.getVerticalScrollBar().setValue(0));
    }

    /**
     * Returns the profile panel associated with this profile page.
     * @return The ProfilePanel instance.
     * @precondition The ProfilePagePanel must have been initialized.
     * @postcondition The current ProfilePanel is returned.
     */
    public ProfilePanel getProfilePanel() {
        return this.profilePanel;
    }

    /**
     * Refreshes the profile feed by resetting the profile feed panel and the scroll pane.
     * This is typically used to update the feed after a change has occurred, such as a new post.
     * @precondition The ProfileFeedPanel is updated and requires a refresh.
     * @postcondition The profile feed and scroll pane are reset, and the layout is refreshed.
     */
    public void refreshProfileFeed() {
        // Set profileFeedPanel to a new object (after updating FeedPanel)
        profileFeedPanel = new ProfileFeedPanel();
        // Remove the current scroll pane and reset it
        remove(scrollPane);
        setScrollPane();
        add(scrollPane, BorderLayout.CENTER);

        // Refresh the layout
        revalidate();
        repaint();
    }

    public void refreshProfilePoint(){
        profilePanel.updatePointLabel();
    }
}
