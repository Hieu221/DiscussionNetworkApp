package gui;
import java.awt.BorderLayout;

import javax.swing.JPanel;
import utility.GeneralPageSortStrategy;

/**
 * @author Tabbie Brantley 
 * HomePageFeedPanel is the panel that holds the home page feed
 * @class invariant only the HomePageSortStrategy is used
 */
public class HomePageFeedPanel extends JPanel{

    private FeedPanel feedPanel;  

    /**
     * Constructor for HomePageFeedPanel
     * @precondition n/a
     * @postcondition n/a
     */
    public HomePageFeedPanel(){
        this.feedPanel = new FeedPanel(new GeneralPageSortStrategy());
        this.setLayout(new BorderLayout());;
        this.add(this.feedPanel, BorderLayout.CENTER);
    }

     /**
     * createHomePageFeedPanel repaints to refresh the panel
     * @return the current instance
     * @precondition n/a
     * @postcondition n/a
     */
    public HomePageFeedPanel createHomePageFeedPanel(){
        this.feedPanel.repaint();
        return this;
    }
    
}