package gui;

/**
 * @author all
 * CreateAccountWindow window view for creating an account
 * @class invariant.......
 */


//imports
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;

import core.NetworkSystem;
import core.UserAccount;

public class NetworkWindow {
    
    //GridBagConstraint
    private GridBagConstraints c;
    private JFrame windowFrame;
    private JPanel mainPanel;

    private ProfilePagePanel profilePage;
    private MenuBarPanel menuBarPanel;
    private HomePagePanel homePage;
    private LeaderboardPage leaderboardPage;
    private CategoryPage categoriesPage;


    /**
     * Constructor for NetworkWindow
     * @precondition n/a
     * @postcondition n/a
     */
    public NetworkWindow() {

        //creating JFrame and JPanel with JPanel has GridBagLayout
        this.windowFrame = new JFrame();
        this.windowFrame.setLayout(new BorderLayout());
        //this.windowFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.menuBarPanel = new MenuBarPanel();
        this.windowFrame.add(this.menuBarPanel, BorderLayout.NORTH);
        this.windowFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);            

    }

    /**
     * displayWindow sets the windowFrame to visible
     * @precondition n/a
     * @postcondition n/a
     */
    public void displayWindow(){
        this.windowFrame.setVisible(true);   
    }

        
    /**
     * closeWindow sets the windowFrame visible to false
     * @precondition n/a
     * @postcondition n/a
     */
    public void closeWindow(){
        this.windowFrame.setVisible(false);   
    }

    /**
     * displayProfilePage removes content from the windowFrame and then
     * add the menuBarPanel and the profilePage
     * @param curUser the current user logged into the system as a UserAccount
     * @preocdintion n/a
     * @postcondition n/a
     */
    public void displayProfilePage(UserAccount curUser){
        this.windowFrame.getContentPane().removeAll();
        this.windowFrame.add(this.menuBarPanel, BorderLayout.NORTH);
        
        this.profilePage = new ProfilePagePanel();
                
        windowFrame.add(this.profilePage, BorderLayout.CENTER);
        windowFrame.revalidate();
        windowFrame.repaint();  
    }

    /**
     * Accessor for profilePage
     * @return this.profilePage as a ProfilePagePanel
     * @precondition n/a
     * @postcondition n/a
     */
    public ProfilePagePanel getProfilePagePanel(){
        return this.profilePage;
    }

    /**
     * displayHomePage removes content from the windowFrame and then
     * add the menuBarPanel and the HomePage
     * @param curUser the current user logged into the system as a UserAccount
     * @preocdintion n/a
     * @postcondition n/a
     */
    public void displayHomePage(UserAccount curUser){
        this.windowFrame.getContentPane().removeAll();

        this.windowFrame.add(this.menuBarPanel, BorderLayout.NORTH);

        this.homePage = new HomePagePanel();
                
        this.windowFrame.add(homePage, BorderLayout.CENTER);
        this.windowFrame.revalidate();
        this.windowFrame.repaint();  
    }

    
/**
     * displayLeaderboardPage removes content from the windowFrame and then
     * add the menuBarPanel and the leaderboardPage
     * @param curUser the current user logged into the system as a UserAccount
     * @preocdintion n/a
     * @postcondition n/a
     */
    public void displayLeaderboardPage(UserAccount curUser){

        this.windowFrame.getContentPane().removeAll();
    
        this.windowFrame.add(this.menuBarPanel, BorderLayout.NORTH);
    
        
        List<UserAccount> topUsers = NetworkSystem.getInstance().getTopUsers();
        
        System.out.println("DISPLAY LEADER BOEAD");
        System.out.println(topUsers);
        
        this.leaderboardPage = new LeaderboardPage(topUsers);
    
        this.windowFrame.add(this.leaderboardPage, BorderLayout.CENTER);
        this.windowFrame.revalidate();
        this.windowFrame.repaint();  
    }
    
    

    /**
     * displayCategoriesPage removes content from the windowFrame and then
     * add the menuBarPanel and the categoriesPage
     * @param curUser the current user logged into the system as a UserAccount
     * @preocdintion n/a
     * @postcondition n/a
     */
     public void displayCategoriesPage(UserAccount curUser) {
        this.windowFrame.getContentPane().removeAll();

        this.windowFrame.add(this.menuBarPanel, BorderLayout.NORTH);
    
        
    
        this.categoriesPage = new CategoryPage();

        this.windowFrame.add(this.categoriesPage, BorderLayout.CENTER);
        this.windowFrame.revalidate();
        this.windowFrame.repaint();
    }


    /**
     * Accessor for the menuBarPanel
     * @return this.menuBarPane as a MenuBarPanel
     * @precondition n/a
     * @postcondition n/a
     */
    public MenuBarPanel getMenuBar(){
        return this.menuBarPanel;
    }
    
    /**
     * Accessor for windowFrame
     * @return this.windowFrame as a JFrame
     * @precondition n/a
     * @postcondition n/a
     */
    public JFrame getWindowFrame(){
        return this.windowFrame;
    }
}