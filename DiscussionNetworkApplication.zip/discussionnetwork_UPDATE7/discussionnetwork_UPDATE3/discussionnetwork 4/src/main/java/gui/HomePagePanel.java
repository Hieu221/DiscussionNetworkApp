package gui;
/**
 * @author Tabbie Brantley
 * HomePagePanel is the panel that holds the home page
 * @class invariant the HomePageSortStrategy will only be used with the homeFeedPanel
 */

//imports
import core.NetworkSystem;
import core.UserAccount;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;

public class HomePagePanel extends JPanel {
    private HomePageFeedPanel homeFeedPanel;
    private JScrollPane scrollPane;

    /**
     * Constructor for HomePagePanel
     * @precondition n/a
     * @postcondition n/a
     */
    public HomePagePanel() {
        UserAccount curUser = NetworkSystem.getInstance().getCurrentUser();
        this.homeFeedPanel = new HomePageFeedPanel();
        JPanel west = new JPanel();
        JPanel east = new JPanel();
        
        int panelWidth = NetworkSystem.getInstance().getWidth() / 5; 
        west.setPreferredSize(new Dimension(panelWidth, this.getHeight())); 
        east.setPreferredSize(new Dimension(panelWidth, this.getHeight())); 

        west.setBackground(new Color(219, 231, 252));
        east.setBackground(new Color(219, 231, 252));

        this.setLayout(new BorderLayout());
        setScrollPane();
        this.add(scrollPane, BorderLayout.CENTER); // Add the scroll pane here
        this.add(west, BorderLayout.WEST);
        this.add(east, BorderLayout.EAST);
    }

    /**
     * setScrollPane sets a scroll pane for the homeFeedPanel
     * @precondition n/a
     * @postcodntion n/a
     */
    public final void setScrollPane() {
        scrollPane = new JScrollPane(this.homeFeedPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.getVerticalScrollBar().setValue(0);
        SwingUtilities.invokeLater(() -> scrollPane.getVerticalScrollBar().setValue(0));
    }
}