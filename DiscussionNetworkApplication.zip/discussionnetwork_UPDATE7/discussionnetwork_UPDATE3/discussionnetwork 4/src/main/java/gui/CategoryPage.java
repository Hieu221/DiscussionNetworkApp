package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import core.NetworkSystem;
import core.Post;
import utility.GeneralPageSortStrategy;


/**
 * @author Lewis Cox
 * CategoryPage is a JPanel that shows the posts and are  filtered by category
 * 
 */
public class CategoryPage extends JPanel{
    private JPanel postPanel;
    private JScrollPane scrollPane;

    /**
     * 
     * CategoryPage
     * layout with category selection buttons and post display panel
     */
    public CategoryPage(){
        postPanel = new JPanel();
        postPanel.setLayout(new BoxLayout(postPanel, BoxLayout.Y_AXIS));

        this.setLayout(new BorderLayout());

        
        JPanel west = new JPanel();
        JPanel east = new JPanel();

        
        int panelWidth = NetworkSystem.getInstance().getWidth() / 5; 
        west.setPreferredSize(new Dimension(panelWidth, this.getHeight())); 
        east.setPreferredSize(new Dimension(panelWidth, this.getHeight())); 

       
        west.setBackground(new Color(219, 231, 252));
        east.setBackground(new Color(219, 231, 252));

        
        this.add(new CategoryButtonPanel(), BorderLayout.NORTH);

        
        this.add(postPanel, BorderLayout.CENTER);

        
        this.add(west, BorderLayout.WEST);
        this.add(east, BorderLayout.EAST);

        
        setScrollPane();
        this.add(scrollPane, BorderLayout.CENTER);
    
    }

    /**
     * displayed posts based on the selected category
     * 
     * @param category the category whose posts should be displayed
     */
    public void updateCategoryPosts(String category) {
        postPanel.removeAll();

        // loops through the list of all posts
        for (Post post : NetworkSystem.getInstance().getPostsList()) {
            // post category matches the selected category and adds it to the panel
            if (post.getCategory().equals(category)) {
                postPanel.add(post.getCompletePostPanel(new GeneralPageSortStrategy()));
            }
        }

        
        this.revalidate();
        this.repaint();
    }

    /**
     * Wraps the post panel in a scroll pane.
     * 
     */
    public final void setScrollPane() {
        scrollPane = new JScrollPane(postPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.getVerticalScrollBar().setValue(0);
    }
}