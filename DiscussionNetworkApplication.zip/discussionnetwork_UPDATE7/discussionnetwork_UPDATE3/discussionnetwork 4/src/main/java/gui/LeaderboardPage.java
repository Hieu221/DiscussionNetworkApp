
package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;

import core.NetworkSystem;
import core.UserAccount;

/**
 * @author Lewis Cox
 * LeaderboardPage displays the leaderboard for users and it sorted by points
 */
public class LeaderboardPage extends JPanel {
    private JList<String> leaderboardList; 
    private JScrollPane scrollPane;        
    private JPanel listUser;
    /**
     * Constructor for the LeaderboardPage
     * Initializes the layout and adds users to the leaderboard
     * 
     * @param users list of UserAccount objects to be displayed in the leaderboard
     */
    public LeaderboardPage(List<UserAccount> users) {
        this.setLayout(new BorderLayout()); 
        
        
        JPanel west = createSidePanel();
        JPanel east = createSidePanel();

        
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBackground(Color.WHITE);

        // Add leaderboard rank label to the center panel
        JLabel leaderboardLabel = new JLabel("LEADERBOARD RANK", SwingConstants.CENTER);
        leaderboardLabel.setOpaque(true); 
        leaderboardLabel.setBackground(new Color(173, 216, 230)); 
        leaderboardLabel.setPreferredSize(new Dimension(centerPanel.getWidth(), 100)); 
        centerPanel.add(leaderboardLabel, BorderLayout.NORTH); // Add label to the top of the center panel

        // Populate the leaderboard and add the scrollPane to the center panel
        populateLeaderboard(users);
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        this.add(centerPanel, BorderLayout.CENTER);  
        this.add(west, BorderLayout.WEST);           
        this.add(east, BorderLayout.EAST);           
    }

    private JPanel createSidePanel() {
        JPanel sidePanel = new JPanel();
        int panelWidth = NetworkSystem.getInstance().getWidth() / 5; 
        sidePanel.setPreferredSize(new Dimension(panelWidth, this.getHeight()));
        sidePanel.setBackground(new Color(219, 231, 252)); 
        return sidePanel;
    }

    /**
     * adds to the leaderboard with the list of users
     * 
     * @param users list of UserAccount objects to be displayed in the leaderboard
     */
    public void populateLeaderboard(List<UserAccount> users) {
        
        DefaultListModel<String> listModel = new DefaultListModel<>();

        // sorts users by points in descending order and add to the list model
        users.stream()
             .sorted((u1, u2) -> Integer.compare(u2.getPoints(), u1.getPoints()))
             .limit(5)
             .forEach(user -> listModel.addElement(user.getUsername() + ": " + user.getPoints() + " points"));

        
        leaderboardList = new JList<>(listModel);
        leaderboardList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        scrollPane = new JScrollPane(leaderboardList);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); 
        scrollPane.getVerticalScrollBar().setValue(0); 
    }
}