package utility;
import java.util.ArrayList;

import core.Post;

/**
 * The SortPostStrategy interface defines a strategy for sorting posts. 
 * This interface is used in the context of a post feed, where posts need to be sorted 
 * @author Hieu Truong
 */
public interface SortPostStrategy {

    /**
     * Sorts the posts based on a specific strategy.
     * The implementing class should define how the posts are sorted and filtered.
     * @return An ArrayList of sorted and filtered Post objects.
     * @precondition The system should have a list of posts available for sorting.
     * @postcondition A sorted and filtered list of posts is returned according to the specific strategy.
     */
    public ArrayList<Post> sortPost();
}
