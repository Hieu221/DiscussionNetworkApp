package utility; 
import java.util.ArrayList;

import core.NetworkSystem;
import core.Post;

/**
 * @authoer Tabbie Brantley
 * GeneralPageSortStrategy implements the SortPostStrategy
 * @class invariant the sortPost() method will override
 */
public class GeneralPageSortStrategy implements SortPostStrategy{

    /**
     * sortPost overrides the method from SortPostStrategy
     * @return the posts
     * @precondition n/a
     * @postcondition n/a
     */
    @Override
    public ArrayList<Post> sortPost() {
        ArrayList<Post> allPosts = NetworkSystem.getInstance().getPostsList();
        ArrayList<Post> homePosts = new ArrayList<>();

        for (int i = NetworkSystem.getInstance().getPostsList().size()-1; i >= 0; i--){
            homePosts.add(NetworkSystem.getInstance().getPostsList().get(i));
        }
        System.out.println("REQUIRE:" + allPosts);
        return homePosts;
    }
}
