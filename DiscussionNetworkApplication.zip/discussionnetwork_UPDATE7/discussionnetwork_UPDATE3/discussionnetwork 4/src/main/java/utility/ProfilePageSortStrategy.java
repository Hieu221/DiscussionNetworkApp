package utility;
import java.util.ArrayList;

import core.NetworkSystem;
import core.Post;

/**
 * ProfilePageSortStrategy implements SortPostStrategy interface.
 * It is used to sort and filter posts based on the current user's profile. 
 * This strategy is typically used to display posts on the user's profile page.
 * @author Hieu Truong
 */
public class ProfilePageSortStrategy implements SortPostStrategy {

    /**
     * Sorts the posts to only include those created by the current user.
     * The posts are returned in reverse order, with the most recent posts appearing first.
     * @return An ArrayList of Post objects created by the current user, in reverse chronological order.
     * @precondition The NetworkSystem must be initialized and contain a list of posts.
     *               The current user must be set in the NetworkSystem.
     * @postcondition list of posts in the profile page made by the current user is returned.
    */
    @Override
    public ArrayList<Post> sortPost() {
        //get the list of all posts in the system
        ArrayList<Post> allPosts = NetworkSystem.getInstance().getPostsList();
        ArrayList<Post> requirePost = new ArrayList<>();
        
        //go through the posts in reverse order (most recent first)
        for (int i = allPosts.size()-1; i>= 0; i--) {
            
            if (allPosts.get(i).getOwner().getUsername().equals(NetworkSystem.getInstance().getCurrentUser().getUsername())){
                requirePost.add(allPosts.get(i));
            }
        }
        
        //check
        System.out.println("REQUIRE:" + requirePost);
        return requirePost;
    }
}
