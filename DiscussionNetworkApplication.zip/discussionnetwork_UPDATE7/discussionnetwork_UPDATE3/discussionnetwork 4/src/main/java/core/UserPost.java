package core;

import javax.swing.JPanel;
/**
 * The UserPost class represents an original post created by a user in the system.
 * It extends the Post class and provides additional details specific to the user.
 * @author Hieu Truong
 */
public class UserPost extends Post {

    /**
     * Constructs a UserPost object with the given content and owner.
     * @param content: The content of the post.
     * @param owner: the UserAccount, who that created the post.
     * @precondition content cannot be null or empty, and owner must be a valid UserAccount.
     * @postcondition A new UserPost object is created with the specified content and owner.
     */
    public UserPost(String content, UserAccount owner){
        //calls the superclass {@link Post}'s constructor to initialize the post.
        super(content, owner);
    }

    /**
     * Returns additional details for this post.
     * In this case, it returns null, meaning no extra details are provided.
     * @return JPanel representing the additional details for the post, or null if no extra details are provided.
     * @precondition The UserPost object has been created.
     * @postcondition null is returned, as no extra details are defined for the UserPost class.
     */
    @Override
    public JPanel getExtraDetail() {
        return null;
    }
}
