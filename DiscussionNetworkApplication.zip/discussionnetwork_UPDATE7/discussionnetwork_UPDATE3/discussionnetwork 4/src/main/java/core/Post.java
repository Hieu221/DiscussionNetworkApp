package core;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import controller.PostObserver;
import utility.SortPostStrategy;


/**
 * Post is an Abstract class representing a Post in the system.
 * Acts as the Subject in the Observer pattern and the Model in the MVC architecture.
 * 
 * @author Hieu Truong
 */
public abstract class Post implements Serializable {
    private final String content;
    private String datePulish;
    private String category;
    private int point;
    private final UserAccount owner;
    private int ID;

    private HashMap<String, String> interactList;
    private JPanel postPanel;
    private JButton[] buttons;
    private JTextArea pointArea;

    private final int width = NetworkSystem.getInstance().getWidth();
    private final int height = NetworkSystem.getInstance().getHeight();

    /**
     * Constructs a Post object with the specified content and owner.
     * @param content: the content of the post.
     * @param owner: the UserAccount that owns this post.
     */
    public Post(String content, UserAccount owner) {
        this.content = content;
        this.owner = owner;
        this.point = 0;
        this.interactList = new HashMap<>();
        this.category = "";
        ZoneId zoneId = ZoneId.of("America/New_York");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        this.datePulish = LocalDate.now(zoneId).format(formatter);
    }

    /**
     * Sets the unique ID for this post.
     * 
     * @param id the unique identifier to set.
     */
    public void setID(int id) {
        this.ID = id;
    }

    /**
     * Updates the points of the post.
     * 
     * @param number the amount to increment or decrement the points.
     *               
     * @Precondition: number is int and !=0
     * @Postcondition: The points of the post are updated by number, the textArea of point is updated
     */
    public void updatePoint(int number) {
        NetworkSystem.getInstance().updatePointForUser(owner.getUsername(), number);
        point += number;
        pointArea.setText("Point: " + point);
        postPanel.repaint();
    }

    /**
     * Sets the category of the post.
     * 
     * @param category the category to set.
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * Gets the owner of the post.
     * 
     * @return the UserAccount object that owns the post.
     */
    public UserAccount getOwner() {
        return owner;
    }

    /**
     * Gets the category of the post.
     * 
     * @return the category of the post, or an empty string if the category is null.
     */
    public String getCategory() {
        return category == null ? "" : category;
    }

    /**
     * Gets the ID of the post.
     * 
     * @return the post's unique identifier.
     */
    public int getPostID() {
        return ID;
    }

    /**
     * Adds an interaction to the post.
     * @param username: the username of the account that interact with this post
     * @param interact: the type of interaction
     */
    public void addInteract(String username, String interact){
        interactList.put(username, interact);
    }
        
    /**
     * Remove an interaction to the post
     * @param username: the username of the account that interact with this post
     * @precondition the interactList contain the username
     * @postcondition the value with the key of username is removed
     */
    public void removeInteract(String username){
        if (interactList.containsKey(username)){
            interactList.remove(username);
        }
    }

    /**
     * Get the kind of interaction
     * @param username: the username of the account that interact with this post
     * @return the interaction String
     */
    public String getInteract(String username){
        if (interactList.containsKey(username)){
            return interactList.get(username);
        }
        return "";
    }

    /**
     * @return the String represents a post object
     */
    @Override
    public String toString(){
        return content + " " + owner.getAccountName();
    }

    /**
     * Creates a JPanel representing the post's basic information.
     * The panel contains the post's avatar, author, date, points, and category.
     * @return JPanel representing the post's basic information. 
     */
    public JPanel getThisPostPanel() {
        
        JPanel thisPanel = new JPanel(new BorderLayout());

        //set user interface of the avatar 
        JLabel avatar = new JLabel(String.valueOf(owner.getAccountName().charAt(0)).toUpperCase(), SwingConstants.CENTER);
        avatar.setPreferredSize(new Dimension(30, 30));
        avatar.setOpaque(true);
        avatar.setBackground(Color.PINK);
        avatar.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        //set user interface of the author 
        JTextArea author = new JTextArea(owner.getAccountName() + " | " + datePulish
                + " | Post ID: " + ID + " | ");
        author.setOpaque(false);
        author.setEditable(false);

        //set  user interface of the point
        pointArea = new JTextArea("Point: " + point);
        pointArea.setEditable(false);
        pointArea.setOpaque(false);

        //set  user interface of the category
        JTextArea categoryArea = new JTextArea(" | " + category);
        categoryArea.setEditable(false);
        categoryArea.setOpaque(false);

        //set user interface of the information of the post 
        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        infoPanel.add(avatar);
        infoPanel.add(author);
        infoPanel.add(pointArea);
        infoPanel.add(categoryArea);

        thisPanel.add(infoPanel, BorderLayout.NORTH);

        //set user interface for the content
        JTextArea contentArea = new JTextArea(content);
        contentArea.setEditable(false);
        contentArea.setLineWrap(true);
        contentArea.setWrapStyleWord(true);
        //contentArea.setBounds(15, 0, width / 5 * 3 - 40, height / 15 * 5);
        contentArea.setBounds(15, 0, contentArea.getWidth() - 40, contentArea.getHeight() * 5);
        contentArea.setBorder(new EmptyBorder(10, 10, 10, 10));
        thisPanel.add(contentArea, BorderLayout.CENTER);

        return thisPanel;
    }

    /**
     * Abstract method to retrieve additional details for the post.
     * 
     * @return a JPanel containing the additional details.
     */
    public abstract JPanel getExtraDetail();

    /**
     * Constructs a complete JPanel for the post, including basic and additional details.
     * 
     * @param displayStrategy the strategy for displaying the post.
     * @return the complete JPanel for the post.
     */
    public JPanel getCompletePostPanel(SortPostStrategy displayStrategy) {
        postPanel = new JPanel(new BorderLayout());
        postPanel.setBackground(Color.WHITE);

        Border innerBorder = BorderFactory.createEmptyBorder(15, 15, 15, 15);
        Border outerBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY, 2);
        postPanel.setBorder(BorderFactory.createCompoundBorder(outerBorder, innerBorder));

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.add(getThisPostPanel());

        //if this post is a repost, it needs to add the information of the original post
        if (getClass().getSimpleName().equals("Repost")) {
            contentPanel.add(getExtraDetail());
        }

        ArrayList<String> buttonNameList = new ArrayList<>(Arrays.asList("Agree", "Disagree", "Repost"));
        //if the page is not profile page, it cannot have the delete button
        if (displayStrategy.getClass().getSimpleName().equals("ProfilePageSortStrategy")) {
            buttonNameList.add("Delete");
        }
        
        //set the button panel, which contains multiple buttons
        buttons = new JButton[buttonNameList.size()];
        JPanel buttonPanel = new JPanel(new GridLayout(1, buttonNameList.size()));
        buttonPanel.setBackground(Color.WHITE);

        for (int i = 0; i < buttonNameList.size(); i++) {
            buttons[i] = new JButton(buttonNameList.get(i));
            buttons[i].setBackground(Color.WHITE);
            buttons[i].setContentAreaFilled(true);
            buttons[i].setOpaque(true);
            buttons[i].addActionListener(new PostObserver(this));
            buttons[i].setBorderPainted(false);
            buttonPanel.add(buttons[i]);
        }

        // Highlight buttons based on the current user interaction with this post
        String currentUserInteraction = getInteract(NetworkSystem.getInstance().getCurrentUser().getUsername());
        if (currentUserInteraction.equals("Agree")) {
            buttons[0].setBackground(new Color(219, 231, 252));
        } else if (currentUserInteraction.equals("Disagree")) {
            buttons[1].setBackground(new Color(219, 231, 252));
        }

        postPanel.add(contentPanel, BorderLayout.CENTER);
        postPanel.add(buttonPanel, BorderLayout.SOUTH);

        return postPanel;
    }

    /**
     * Gets the "Agree" button for the post.
     * 
     * @return the JButton for "Agree".
     */
    public JButton getAgreeButton() {
        return buttons[0];
    }

    /**
     * Gets the "Disagree" button for the post.
     * 
     * @return the JButton for "Disagree".
     */
    public JButton getDisagreeButton() {
        return buttons[1];
    }
        
}