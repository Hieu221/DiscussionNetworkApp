package core;
/**
 * @author Tabbie Brantley
 * UserAccount class for the users is Serializable
 * @class invariant the USERNAME String cannot be changed
 * */

import java.io.Serializable;

public class UserAccount implements Serializable{
    private final String USERNAME;
    private String accountName;
    private String password;    
    private int points;

    /**
     * Constructor for UserAccount
     * @param accountNm the account name as a String
     * @param userNm the username as a String
     * @param pwd the password as a String
     * @precondition ((8 <= accountName.length()) && (accountName.length.() <= 20)) 
     * && ((8 <= userNm.length()) && (userNm.length <= 20)) 
     * && ((8 <= pwd.length()) && (pwd.length <= 20))
     * @postcondition points are initialized to 0
     */
    public UserAccount(String accountNm, String userNm, String pwd){
        this.accountName = accountNm;
        this.USERNAME = userNm;
        this.password = pwd;
        this.points = 0;
    }

    /**
     * Accessor for username
     * @return USERNAME as a String
     * @precondition n/a
     * @postcondition n/a
     */
    public String getUsername(){
        return this.USERNAME;
    }
    
    /**
     * Accessor for password
     * @return password as a String
     * @precondition n/a
     * @postcondition n/a
     */
    public String getPassword(){
        return this.password;
    }
    
    /**
     * Accessor for points
     * @return points as an int
     * @precondition n/a
     * @postcondition n/a
     */
    public int getPoints(){
        return this.points;
    }
    
    /**
     * Mutator for points
     * @param val the value that the points should increase or decrease by as an int
     * @precondition n/a
     * @postcondition this.points >= 0
     */
    public void updatePoints(int val){
        this.points += val;
    }

    /**
     * Mutator for accountName
     * @param newName the new name as a String
     * @precondition (8 <= newName.length()) && (newName.length() <= 20)
     * @postcondition the accountName is changed
     */
    public void setName(String newName){
        this.accountName = newName;
    }
    /**
     * Mutator for password
     * @param newPWD the new password as a String
     * @precondition (8 <= newPwd.length()) && (newPwd.length() <= 20)
     * @postcondition the password is changed
     */
    public void setPassword(String newPwd){
        this.password = newPwd;
    }

    /**
     * Accessor for accountName
     * @return accountName as a String
     * @precondition n/a
     * @postcondition n/a
     */
    public String getAccountName(){
        return this.accountName;
    }
    @Override
    public String toString(){
        return USERNAME + " " + points;
    }
}