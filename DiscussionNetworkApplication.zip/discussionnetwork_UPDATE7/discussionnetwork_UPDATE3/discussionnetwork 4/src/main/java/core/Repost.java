package core;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

/**
 * The Repost class represents a post that is a repost of an original post.
 * It extends the Post class and adds functionality specific to reposting
 * @author Hieu Truong
 */
public class Repost extends Post {
    private final Post originalPost;

    /**
     * Constructs a Repost object with the given content, owner, and original post.
     * The constructor calls the superclass {@link Post}'s constructor to initialize the post 
     * @param content: The content of the repost.
     * @param owner: The UserAccount that created the repost.
     * @param oriPost: The UserPost that is being reposted.
     * @precondition content cannot be null or empty, and owner and oriPost must be valid.
     * @postcondition A new Repost object is created with the specified content, owner, and original post.
     */
    public Repost(String content, UserAccount owner, Post oriPost){
        //calls the superclass Post constructor to initialize the post
        super(content, owner);
        this.originalPost = oriPost;
    }

    /**
     * Returns the additional details for this repost.
     * This method returns a JPanel that represents the original post, with an added border for visual separation.
     * @return A JPanel representing the original post with added padding.
     * @precondition The Repost object has been created and contains a reference to an original post.
     * @postcondition The JPanel of the original post is returned
     */
    @Override
    public JPanel getExtraDetail() {
        JPanel oriPanel = originalPost.getThisPostPanel();
        oriPanel.setBorder(new EmptyBorder(10, 25, 10, 5)); // Add padding to the original post panel
        return oriPanel;
    }
}
