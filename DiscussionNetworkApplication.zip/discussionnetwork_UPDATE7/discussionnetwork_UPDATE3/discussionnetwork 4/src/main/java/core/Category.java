package core;

/**
 * @author Lewis Cox
 * category in the system
 */
public class Category {
    private String name;

    /**
     * Constructs a Category object
     * 
     * @param name of the category
     */
    public Category(String name) {
        this.name = name;
    }

    /**
     * gets the name of the category
     * 
     * @return the name of the category
     */
    public String getName() {
        return name;
    }

    /**
     * updates the name of the category
     * 
     * @param name the new name for the category
     */
    public void setName(String name) {
        this.name = name;
    }
}