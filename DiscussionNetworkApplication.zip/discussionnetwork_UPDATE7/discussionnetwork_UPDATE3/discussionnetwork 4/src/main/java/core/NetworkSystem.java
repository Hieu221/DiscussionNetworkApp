package core;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import controller.LoginController;
import controller.NetworkWindowController;
import gui.CreateAccountWindow;
import gui.LoginWindow;
import gui.NetworkWindow;


/**
 * @author all
 * Network system, the class for the project
 * @class invariant: only one instance of NetworkSystem is created
 */
public class NetworkSystem implements Cloneable, Serializable {
    //attributes
    private static NetworkSystem instance = new NetworkSystem();

    private HashMap<String, UserAccount>  userAccountsList = new HashMap<>();
    private UserAccount currentUser;

    private ArrayList<Post> postsList = new ArrayList<>();
    private int postID; //this will set the id for the new post

    private NetworkWindow networkWindow =  new NetworkWindow();
    private NetworkWindowController networkWindowController = new NetworkWindowController(this.networkWindow);

    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    private final int WIDTH = screenSize.width;
    private final int HEIGHT = screenSize.height;

    private LoginWindow loginWindowView;
    
    private HashMap<String, Category> categories = new HashMap<>();

    private static final String USER_ACCOUNTS_FILE = "/userAccounts.ser";
    private static final String POSTS_FILE = "/posts.ser";
    private String dataDirectory = System.getProperty("user.dir") + "/data";  // For example, "data" directory under your project folder


    /**
     * Constructor of the NetworkSystem
     * @precondition n/a
     * @postcondition loadConfig() and ensureDirectoryExists is called
     */
    private NetworkSystem(){
        this.ensureDirectoryExists(); 
        this.loadSystemData(); 
    }

    /**
     * @author Tabbie Brantley
     * getInstance returns the only instance
     * @return instance as a NetworkSystem
     * @precondition n/a
     * @postcondition n/a
     */
    public static synchronized NetworkSystem getInstance() {
        if (instance == null) {
            System.out.println("Creating new NetworkSystem instance...");
            instance = new NetworkSystem();
        } 
        return instance;
    }

    /**
     * @author TabbieBrantley
     * ensuresDirectoryExists makes sure that the directory exists, and if it does not
     * it creates it
     * @precondition dataDirectory must have a valid path
     * @postcondition the directory is created if it does not exist
     */
    private void ensureDirectoryExists() {
        Path path = Paths.get(this.dataDirectory);
        if (!Files.exists(path)) {
            try {
                Files.createDirectories(path);  // Create the directory if it doesn't exist
                System.out.println("Created directory: " + this.dataDirectory);
            } catch (IOException e) {
                System.err.println("Error creating directory: " + e.getMessage());
            }
        }
    }

    /**
     * @author TabbieBrantley
     * loadSystemsData loads the UserAccount and Post data
     * @precondition n/a
     * @postcondition this.UserAccountsList and this.postsLists should have the
     * proper data
     */
    private void loadSystemData() {
        this.userAccountsList = this.loadUserAccounts();
        this.postsList = this.loadPosts();
    }

    /**
     * @author Tabbie Brantley
     * loadUserAccounts retrieves all the user account files in USER_ACCOUNTS_FILE
     * @precondition n/a
     * @postocondition the user accounts are added to the userAccountsList HashMap
     */
    private HashMap<String, UserAccount> loadUserAccounts() {
        try (ObjectInputStream inStream = new ObjectInputStream(
                new FileInputStream(this.dataDirectory + USER_ACCOUNTS_FILE))) {
            return (HashMap<String, UserAccount>) inStream.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading user accounts: " + e.getMessage());
        }
        return new HashMap<>(); 
    }


    /**
     * @author Tabbie Brantley
     * loadPosts retrieves all the post files in POSTS_FILE
     * @precondition n/a
     * @postocondition the posts are added to the postsList
     */
    private ArrayList<Post> loadPosts() {
        try (ObjectInputStream inStream = new ObjectInputStream(
                new FileInputStream(this.dataDirectory + POSTS_FILE))) {
            return (ArrayList<Post>) inStream.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading posts: " + e.getMessage());
        }
        return new ArrayList<>(); // Return empty list if loading fails
    }


    /**
     * @author Tabbie Brantley
     * addUserAccounts creates and adds a new UserAccount
     * @param accName the account name as a String
     * @param name the account user name as a String
     * @param pw the password as a String
     * @precondition the username should not already exist
     * @postcondition the new user is added to userAccountsList
     */
    public void addUserAccount(String accName, String name, String pw) { 
        if (this.userAccountsList == null) {
            this.userAccountsList = new HashMap<>(); 
        }     
        UserAccount user = new UserAccount(accName, name, pw);
        if (this.checkUserExists(name)) {
            System.out.println("Username already exists");
            return;
        }
        this.userAccountsList.put(user.getUsername(), user);
        this.saveUserAccounts(); 
    }

    /**
     * @author Tabbie Brantley
     * addPosts adds a new post to the postsList
     * @param post the post that is being added
     * @precondition n/a
     * @postcondition the new post is added to postsList
     */
    public void addPosts(Post post) { 
        if (this.postsList == null) {
            this.postsList= new ArrayList<>(); 
        }  
        if (postsList.isEmpty()){
           post.setID(1);
        } else {
        post.setID(postsList.get(postsList.size()-1).getPostID()+1);  
        } 
        this.postsList.add(post);
        //postID += 1;
        System.out.println("Added successfully");
        this.savePosts();
    }

    /**
     * @author Hieu Truong
     * Remove a post in the postsList
     * @param post
     */
    public void removePost(Post post){
        Iterator<Post> iterator = postsList.iterator();
        while (iterator.hasNext()){
            Post currentPost = iterator.next();
            if (currentPost.getPostID() == post.getPostID()){
                iterator.remove();
                break;
            }
        }
    }

    /**
     * @author Tabbie Brantley
     * saveUserAccounts saves all the user account objects to the USER_ACCOUNT_FILE
     * @precondition n/a
     * @postcondition n/a
     */
    public void saveUserAccounts() {
        try (ObjectOutputStream outStream = new ObjectOutputStream(
                new FileOutputStream(this.dataDirectory + USER_ACCOUNTS_FILE))) {
            outStream.writeObject(this.userAccountsList);
            System.out.println("User accounts saved.");
        } catch (IOException e) {
            System.err.println("Error saving user accounts: " + e.getMessage());
        }
    }

    /**
     * @author Tabbie Brantley
     * savePosts saves all the post to the POSTS_FILE
     * @precondition n/a
     * @postcondition n/a
     */
    public void savePosts() {
        try (ObjectOutputStream outStream = new ObjectOutputStream(
                new FileOutputStream(this.dataDirectory + POSTS_FILE))) {
            outStream.writeObject(this.postsList);
            System.out.println("Posts saved.");
        } catch (IOException e) {
            System.err.println("Error saving posts: " + e.getMessage());
        }
    }
    
    /**
     * @author Tabbie Brantley
     * set current user sets the curUser to the UserAccount that is signed in
     * @param curUser the current user as a UserAccount
     * @precondition n/a
     * @postcondition n/a
     */
    public void setCurrentUser(UserAccount curUser){
        this.currentUser = curUser;
    }

    /**
     * @author Tabbie Brantley
     * getCurrentUser returns the current user
     * @precondition n/a
     * @return this.currentUser as a UserAccount
     * @precondition a user must be signed in
     * @postcondition n/a
     */
    public UserAccount getCurrentUser(){
        return this.currentUser;
    }

    /**
     * @author Tabbie Brantley 
     * getNetworkWindow returns the network window
     * @return this.networkWindow as a NetworkWindow
     * @precondition n/a
     * @postcondition n/a
     */
    public NetworkWindow getNetworkWindow(){
        return this.networkWindow;
    }

    /**
     * @author Tabbie Brantley
     * checkUserExists checks if the UserAccount is in the hashmap
     * @param userNm the key as a String
     * @return boolean value, true if exists, false if not
     */
    public boolean checkUserExists(String userNm){
        return this.userAccountsList.containsKey(userNm);
    }

    /**
     * @author Tabbie Brantley
     * Accessor for the userAccountsList HashMap
     * @return this.userAccountsList as a HashMap
     * @precondition n/a
     * @postcondition n/a
     */
    public HashMap<String, UserAccount> getUserAccountsList() {
        return this.userAccountsList;
    }

     /**
     * @author Tabbie Brantley
     * Accessor for the postsList ArrayList
     * @return this.postsList as an ArrayList
     * @precondition n/a
     * @postcondition n/a
     */
    public ArrayList<Post> getPostsList() {
        return this.postsList;
    }

    /**
     * @author Tabbie Brantley
     * Accessor for the HEIGHT 
     * @return this.HEIGHT as an int
     * @precondition n/a
     * @postcondition n/a
     */
    public int getHeight(){
        return this.HEIGHT;
    }

    /**
     * @author Tabbie Brantley
     * Accessor for the WIDTH
     * @return this.WIDTH  as an int
     * @precondition n/a
     * @postcondition n/a
     */
    public int getWidth(){
        return this.WIDTH;
    }

    /**
     * @author Tabbie Brantley
     * usernameExists checks if a username is used in the HashMap usesAccountsLists
     * @param un the username as a String
     * @return boolean value, true if this.userAccountsList containts
     * the key, and false if not
     * @precondition n/a
     * @postcondition n/a
     */
    public boolean usernameExists(String un){
        return this.userAccountsList.containsKey(un);
    }

    /**
     * @author Tabbie Brantley
     * loginUser logs in a user account
     * @param un the username as a String
     * @param pwd the password as a String
     * @return true when passwords match, else will return false
     * @precondition this.usernameExists(un) == ture
     * @postconition this.currentUser == this.userAccountsList.get(un), else return false
     */
    public boolean loginUser(String un, String pwd){
        if (this.usernameExists(un)){
            if (this.userAccountsList.get(un).getPassword().equals(pwd)){
                this.setCurrentUser(this.userAccountsList.get(un));
                return true;
            }
        } 
        return false;
    }

    /**
     * @author Tabbie Brantley
     * openApplication will display the networkWindow homepage
     * @precondition this.getCurrentUser() != null
     * @postcondition the application is displayed using the current user's information
     */
    public void openApplication(){
        this.getNetworkWindow().displayWindow();
        this.networkWindow.displayHomePage(this.getCurrentUser());
    }

    
    /**
    * @author Selin Topac
    * user will click logout button, application will save info and open login window
    * @preconditon this.getCurrentUser() != null
    * @preconditon user must click logout button (in profile page)
    * @postconditon this.getCurrentUser() == null
    * @postconditon network window is closed, login window is opened
    */
    public void logout(){
        System.out.println("logout working");
        this.currentUser = null;
        this.savePosts();
        this.saveUserAccounts();
        this.networkWindow.closeWindow();
        this.networkWindow = new NetworkWindow();
        this.networkWindowController = new NetworkWindowController(this.networkWindow);
        this.login();
    }
    
    /**
    * @author Selin Topac
    * opens the login window
    * @preconditon this.LoginWindowView == null
    * @preconditon this.getCurrentUser() == null
    * @postcondition this.LoginWindowView != null
    */ 
    public void login(){
        this.loginWindowView = new LoginWindow();
        CreateAccountWindow createAccountView = new CreateAccountWindow();
        LoginController loginController = new LoginController(loginWindowView, createAccountView, this);
    }
    /**
     * @author Tabbie Brantley
    * saveSystemState saves the UserAccounts and posts
    * @precondition n/a
    * @postcondition n/a
    */
    public void saveSystemState(){
        this.saveUserAccounts();
        this.savePosts();
        System.out.println("Everything saved!");
    }

    
    /**
    * @author Lewis Cox
    * gets a category by the name
    * @param categoryName
    * @return the category object
     */
    public Category getCategory(String categoryName){
        return categories.get(categoryName);
    }
    /**
    * @author Lewis Cox
    * gets a list of all categories 
    * @return list of categories
    */

    /**
     * 
     * @return
     */
    public List<String> getAllCategories(){
        return new ArrayList<>(categories.keySet());
    }
    
    /**
     * @author Lewis Cox
     * @return 
     */
    public List<UserAccount> getTopUsers() {
        List<UserAccount> sortedUsers = new ArrayList<>(this.userAccountsList.values());
        sortedUsers.sort((u1, u2) -> Integer.compare(u2.getPoints(), u1.getPoints()));  
        return sortedUsers;
    }

    /**
     * @author Hieu Truong
     * @param username the username as a String
     * @param val the value will be add to point
     * @precondition the userAccountList contains key username
     * @postcondition point update to userAccountList.get(username)
     */
    public void updatePointForUser(String username, int val){
        userAccountsList.get(username).updatePoints(val);
    }
    
    /**
     * Main method for running the application
     */
    public static void main(String[] args) {
        NetworkSystem networkSystem = NetworkSystem.getInstance();
        networkSystem.loadPosts();
        networkSystem.loadUserAccounts();
        
        // Print all user accounts to verify the new user was added
        System.out.println("Current users: " + networkSystem.userAccountsList);
        System.out.println("Current posts: " + networkSystem.postsList);

        networkSystem.login();
        networkSystem.savePosts();
        networkSystem.saveUserAccounts();
    }

}