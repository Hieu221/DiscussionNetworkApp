package controller;

import java.util.List;
import core.*;
import gui.LeaderboardPage;

public class LeaderboardController {
    private LeaderboardPage leaderboardPage;
    private List<UserAccount> users;

    /**
     * @author Lewis Cox
     * Constructor to initialize the controller
     * @param leaderboardPage the LeaderboardPage to update
     * @param users the list of users for the leaderboard
     */
    public LeaderboardController(LeaderboardPage leaderboardPage, List<UserAccount> users) {
        this.leaderboardPage = leaderboardPage;
        this.users = users;
        updateLeaderboard(); 
    }

    /**
     * Updates the leaderboard by sorting the user list and refreshing the page
     */
    public void updateLeaderboard() {
        if (users == null || users.isEmpty()) {
            leaderboardPage.populateLeaderboard(List.of()); 
        } else {
            users.sort((u1, u2) -> Integer.compare(u2.getPoints(), u1.getPoints())); 
            leaderboardPage.populateLeaderboard(users); 
        }
    }

    /**
     * updates the list and refreshes the leaderboard
     * @param users the new list of users
     */
    public void setUsers(List<UserAccount> users) {
        this.users = users;
        updateLeaderboard();
    }
}
