package controller;
/**
 * @author Tabbie Brantley
 * The ProfileController class is the controller for the Profile
 * @class invariant user information can be updated only through the ProfileController
 */

import javax.swing.*;

import core.UserAccount;
import gui.ProfilePanel;

import java.awt.*;
import java.awt.event.*;

public class ProfileController {
    //attributes
    private ProfilePanel profileView;
    private JButton editNameB;
    private JButton cancelNameB;
    private JButton saveNameB;
    private JButton editPasswordB;
    private JButton cancelPasswordB;
    private JButton savePasswordB;
    private UserAccount currentUser;
    
    /**
     * Constructor for profile panel
     * @param profilePanelView the view as a ProfilePanel
     * @param curUser the current user as a UserAccount
     * @precondition n/a
     * @postcondition listeners are created
     */
    public ProfileController(ProfilePanel profilePanelView, UserAccount curUser){
        this.profileView = profilePanelView;
        this.currentUser = curUser;
        this.createProfileListeners();
    }

    /**
     * createPorfileLIsteners vreates listeners for the profile
     * @precondition n/a
     * @postcondition listeners are creates
     */
    public void createProfileListeners(){

        this.editNameB = profileView.getEditNameButton();
        //add action listener to editNameB
        this.editNameB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event){
                ProfileController.this.profileView.editName();
            }
        });

        this.cancelNameB = profileView.getCancelNameButton();

        //add action listener to cancelNameB
        this.cancelNameB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event){
                ProfileController.this.profileView.cancelNameEdit();
            }
        });

        this.saveNameB = profileView.getSaveNameButton();

        //add action listener to saveNameB
        this.saveNameB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event){
                String newName = profileView.getNewName().getText();
                if (ProfileController.this.checkNameLength(newName)){
                    ProfileController.this.changeName(newName);
                    ProfileController.this.profileView.closeEditName();
                }
                else{
                    ProfileController.this.profileView.displayNameLengthErrorMessage();
                }
            }
        });


        this.editPasswordB = profileView.getEditPasswordButton();
        //add action listener to editPasswordB
        this.editPasswordB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event){
                ProfileController.this.profileView.editPassword();
            }
        });

        this.cancelPasswordB = profileView.getCancelPasswordEditButton();
        //add action listener to cancelPasswordB
        this.cancelPasswordB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event){
                ProfileController.this.profileView.cancelPasswordEdit();
            }
        });

        this.savePasswordB = profileView.getSavePasswordButton();
        //add action listener to savePasswordB
        this.savePasswordB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event){
                String newPassword = profileView.getNewPassword().getText();
                String confirmedPassword = profileView.getConfirmedPassword().getText();
                if ((ProfileController.this.checkPasswordLength(newPassword)) && 
                    (ProfileController.this.checkPasswordsMatch(newPassword, confirmedPassword))){
                    ProfileController.this.changePassword(newPassword);
                    ProfileController.this.profileView.closeEditPassword();
                } else if(!ProfileController.this.checkPasswordLength(newPassword)){
                    ProfileController.this.profileView.displayPasswordLengthErrorMessage();
                } else {
                    ProfileController.this.profileView.displayPasswordMatchErrorMessage();
                }
                
            }
        });
    }

    /**
     * checkNameLength checks the length of a String to meet requirements
     * @param name the name as a String
     * @return boolean value, true if length is between [8, 20]
     * @precondtion n/a
     * @postcondition n/a
     */
    public boolean checkNameLength(String name){
        return ((8 <= name.length()) && (name.length()<= 20));  
    }

    /**
     * changeName changes the name of the currentUser
     * @param name the new name as a String
     * @precondition n/a
     * @postcondition currentUser's name is updated and the profileView displays the new name
     */
    public void changeName(String name){
        this.currentUser.setName(name);
        this.profileView.updateName(name);
    }

    /**
     * checkPassowordLength checks the length of a String to meet requirements
     * @param pwd is the new password as a String
     * @return boolean value, true if length is between [8, 20]
     * @precondtion n/a
     * @postcondition n/a
     */
    public boolean checkPasswordLength(String pwd){
        return ((8 <= pwd.length()) && (pwd.length()<= 20));  
    }

    
    /**
     * checkPassowordsMatch checks whether two passwords are the same
     * @param pwd is the new password, and confirmedPwd is the confirmed password
     * @return boolean value, true if they the sequence of characters equal each other,
     * false if not
     * @precondtion n/a
     * @postcondition n/a
     */
    public boolean checkPasswordsMatch(String pwd, String confirmedPwd){
        return pwd.equals(confirmedPwd); 
    }

    /**
     * changePassword changes the password of the currentUser
     * @param pwd is the new password as a String
     * @precondition n/a
     * @postcondition currentUser's password is updated
     */
    public void changePassword(String pwd){
        this.currentUser.setPassword(pwd);
    }
}