package controller;
//imports
import java.awt.event.*;
import javax.swing.*;

import core.NetworkSystem;
import gui.CreateAccountWindow;
import gui.LoginWindow;

/**
 * @author Tabbie Brantley and Selin Topac
 * Login Controller for logging into the system and creating an account
 * @class invariant the currentSystem attribute is only for one instance (Singleton pattern)
 */
public class LoginController {
    //LonginWindow attribute loginWindowView
    private LoginWindow loginWindowView;
    //CreateAccountWindow attribute createAccountWindowView
    private CreateAccountWindow createAccountWindowView;
    private NetworkSystem currentSystem;
    
    /*
     * Constructor for LoginController
     * @param lView as LoginWindowView
     * @param curSystem the current NetworkSystem
     * @precondition n/a
     * @postcondition createAccountWindow is initiliazed
     */
    public LoginController(LoginWindow lView, CreateAccountWindow createView, NetworkSystem curSystem) { 
        this.loginWindowView = lView;
        this.createAccountWindowView = createView;
        this.currentSystem = curSystem;
        this.createListeners();    
        this.createWindowListeners();
    }

    /**
     * createtListeners for creating the listeners
     * @precondition createAccountWindowView.getCreateAccountButton() != null &&
     * createAccountWindowView.getReturnToLoginButton() != null &&
     * createAccountWindowView.getJTextFields() != null
     * @postcondition Listeners for the create button and return button are created
     */
    public void createListeners(){

        //loginWindowView Listeners
        JButton loginButton = this.loginWindowView.getLoginButton();
        JButton goToCreateAccountButton = this.loginWindowView.getCreateAccountButton();
        JTextField[] loginTextFields = this.loginWindowView.getJTextFields();
        String[] loginInfo = new String[loginTextFields.length];

        //add actionPerformed to the loginButton
        loginButton.addActionListener(new
        ActionListener() {
            public void actionPerformed(ActionEvent event){
                for (int i = 0; i < loginTextFields.length; i++){
                    loginInfo[i] = loginTextFields[i].getText();
                }
                //check fields match length constraints
                if (LoginController.this.checkLoginLengths(loginInfo[0], loginInfo[1]) == false) {
                    LoginController.this.loginWindowView.displayLengthConstraintMessage();
                }
                //check that username exists
                else if (LoginController.this.checkUsernameExists(loginInfo[0]) == false) {
                    LoginController.this.loginWindowView.displayUsernameNotExistMessage();
                }
                else if (LoginController.this.verifyLogin(loginInfo[0], loginInfo[1]) == false){
                    LoginController.this.loginWindowView.displayPasswordIsNotCorrectMessage();
                }
                else{
                    LoginController.this.loginWindowView.closeLoginWindow();
                    LoginController.this.currentSystem.openApplication();
                }
                
            }   
        });

        //add actionPerformed to goToCreateAccountButton
        goToCreateAccountButton.addActionListener(new
        ActionListener() {
            public void actionPerformed(ActionEvent event){
                //close loginView and open createAccountView
                LoginController.this.loginWindowView.closeLoginWindow();
                LoginController.this.createAccountWindowView.openCreateAccountWindow();
        }
        });
        
        
        //createAccountWindowView Listeners
        JButton createButton = this.createAccountWindowView.getCreateAccountButton();
        JButton returnButton = this.createAccountWindowView.getReturnToLoginButton();

        JTextField[] createTextFields = this.createAccountWindowView.getJTextFields();

        String[] accountInfo = new String[createTextFields.length];

        //add action performed for returnButton
        returnButton.addActionListener(new
            ActionListener() {
                public void actionPerformed(ActionEvent event){
                    //close createAccountWindowView and ope loginWindowView
                    LoginController.this.createAccountWindowView.closeCreateAccountWindow();
                    LoginController.this.loginWindowView.openLoginWindow();
        }
        });

        //add actionPerformed to createButton
        createButton.addActionListener(new
        ActionListener() {
            public void actionPerformed(ActionEvent event){
                for (int i = 0; i < createTextFields.length; i++){
                    accountInfo[i] = createTextFields[i].getText();
                }
                //check fields match length constraints
                if (LoginController.this.checkCreateLengths(accountInfo[0], accountInfo[1], accountInfo[2]) == false) {
                    LoginController.this.createAccountWindowView.displayLengthConstraintMessage();
                }
                //check that passwords match
                else if (LoginController.this.checkPasswords(accountInfo[2], accountInfo[3]) == false) {
                    LoginController.this.createAccountWindowView.displayPasswordNotMatchMessage();
                }
                else if (LoginController.this.currentSystem.checkUserExists(accountInfo[1])){
                    LoginController.this.createAccountWindowView.displayAccountNameAlreadyUsedMessage();
                } else {
                    currentSystem.addUserAccount(accountInfo[0], accountInfo[1], accountInfo[2]);
                    LoginController.this.createAccountWindowView.closeCreateAccountWindow();
                    LoginController.this.loginWindowView.openLoginWindow();
                }
            }   
        });
    }


    /**
     * cheackLoginLenghts to match constraints
     * @param username as String
     * @param pwd as String
     * @return boolean value whether all fields match constraints
     * @precondition n/a
     * @postcondition n/a
     */
    private boolean checkLoginLengths(String username, String pwd){
        return ((8 <= username.length()) && ((username.length()) <= 20)
                && ((8 <= pwd.length()) && ((pwd.length()) <= 20)));
    }

    /**
     * cheackUsernameExists to match constraints
     * @param username as String
     * @param pwd as String
     * @return boolean value username exists in the system
     * @precondition n/a
     * @postcondition n/a
     */
    private boolean checkUsernameExists(String username){
        return this.currentSystem.usernameExists(username);
    }

    /**
     * verfifyLogin to check if user is able to login
     * @param username as String
     * @param pwd as String
     * @return boolean value username exists in the system
     * @precondition n/a
     * @postcondition n/a
     */
    private boolean verifyLogin(String username, String pwd){
        return this.currentSystem.loginUser(username, pwd);
    }


    /**
     * checkCreatelenghts to match constraints
     * @param name as String
     * @param username as String
     * @param pwd as String
     * @return boolean value whether all fields match constraints
     * @precondition n/a
     * @postcondition n/a
     */
    public boolean checkCreateLengths(String name, String username, String pwd){
        return (((8 <= name.length()) && (name.length()<= 20))  
                && ((8 <= username.length()) && ((username.length()) <= 20)
                && ((8 <= pwd.length()) && ((pwd.length()) <= 20))));
    }

    /**
     * Check if passwords match
     * @param pwd as String
     * @param confirmPwd as String
     * @return boolean value whether they match
     * @precondition n/a
     * @postcondition n/a
     */
    public boolean checkPasswords(String pwd, String confirmPwd){
        return (pwd.equals(confirmPwd));
    }
    
    /**
     * createWindowListeners creates listeners for the loginWindowView frame
     * and the createAccountWindowView frame
     * @precondition n/a
     * @postcondition n/a
     */
    public void createWindowListeners(){
        JFrame lFrame = this.loginWindowView.getLoginWindow(); // Assuming `getFrame()` returns the main JFrame
        lFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                NetworkSystem.getInstance().saveSystemState();
            }
        });
        JFrame cFrame = this.createAccountWindowView.getCreateAccountFrame(); // Assuming `getFrame()` returns the main JFrame
        cFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                NetworkSystem.getInstance().saveSystemState();
            }
        });
    }
}