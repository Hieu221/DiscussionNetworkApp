package controller;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import core.NetworkSystem;
import core.Post;
import core.Repost;

/**
 * The PostObserver class is responsible for handling user interactions with a post.
 * This includes actions such as agreeing, disagreeing, reposting, and deleting a post.
 * It updates the post's state and refreshes the profile feed based on the actions performed.
 * @author Hieu Truong
 */
public class PostObserver implements ActionListener {
    private Post post;

    /**
     * Constructs a PostObserver for the specified Post.
     * @param post: the Post object to be observed and interacted with.
     */
    public PostObserver(Post post) {
        this.post = post;
    }

    /**
     * Handles the actions performed on the observed post. 
     * This includes actions such as agreeing, disagreeing, reposting, and deleting. 
     * The post's points and interactions are updated accordingly, and the UI is refreshed.
     * @precondition e != null && e.getSource() instance of JButton
     * @postcondition The state of the post and user interface is updated based on the action performed.
     * @param e the ActionEvent triggered by the user's interaction.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        String currAccount = NetworkSystem.getInstance().getCurrentUser().getUsername();
        String action = e.getActionCommand();

        if (e.getSource() instanceof JButton) {
            if (action.equals("Agree")) {
                handleAgreeAction(currAccount);
            } else if (action.equals("Disagree")) {
                handleDisagreeAction(currAccount);
            } else if (action.equals("Repost")) {
                handleRepostAction();
            } else {
                handleDeleteAction();
            }
        }
    }

    /**
     * Handles the Agree action, updating the post's points and interactions.
     * @precondition  The action command of the event must be "Agree"
     * @postcondition The post's interaction is updated to "Agree" or cleared if re-clicked, change the button color
     * @param currAccount: the username of the current user.
     */
    private void handleAgreeAction(String currAccount) {
        if (post.getInteract(currAccount).equals("Agree")) {
            //current user re-clicks agree, deduct 1 point, de highlight the agree button
            post.updatePoint(-1);
            post.removeInteract(currAccount);
            post.getAgreeButton().setBackground(Color.WHITE);
        } else if (post.getInteract(currAccount).equals("Disagree")) {
            //disagree->agree: +1+1; high-light agree; de-highlight disagree
            post.updatePoint(+2);
            post.addInteract(currAccount, "Agree");
            post.getAgreeButton().setBackground(new Color(219, 231, 252));
            post.getDisagreeButton().setBackground(Color.WHITE);
        } else {
            //from nothing->agree: +1; highlight agree button
            post.updatePoint(1);
            post.addInteract(currAccount, "Agree");
            post.getAgreeButton().setBackground(new Color(219, 231, 252));
        }
    }

    /**
     * Handles the Disagree action, updating the post's points and interactions.
     * @precondition The action command of the event must be "Disagree".
     * @postcondition The post's interaction is updated to "Disagree" or cleared if re-clicked, and change the buttons color
     * @param currAccount the username of the current user.
     */
    private void handleDisagreeAction(String currAccount) {
        if (post.getInteract(currAccount).equals("Disagree")) {
            //current user re-clicks disagree, add 1 point, de-highlight the disagree button
            post.updatePoint(1);
            post.removeInteract(currAccount);
            post.getDisagreeButton().setBackground(Color.WHITE);
        } else if (post.getInteract(currAccount).equals("Agree")) {
            //agree->disagree: +1+1; high-light disagree; de-highlight agree
            post.updatePoint(-2);
            post.addInteract(currAccount, "Disagree");
            post.getDisagreeButton().setBackground(new Color(219, 231, 252));
            post.getAgreeButton().setBackground(Color.WHITE);
        } else {
            //from nothing->disagree: -1; highlight disagree button
            post.updatePoint(-1);
            post.addInteract(currAccount, "Disagree");
            post.getDisagreeButton().setBackground(new Color(219, 231, 252));
        }
    }

    
    /**
     * @author Selin Topac
     * Handles the Repost action
     * @precondition a post should already exist
     * @postcondition a frame that includes the original post and a new panel with a text area for the repost is returned
     * 
     * @return a frame that includes the original post and a new panel with a text area
     */
    private void handleRepostAction() {
        // creates a frame
        JFrame repostFrame = new JFrame();
        repostFrame.setLayout(new BorderLayout());
        // creates a text area for the user to add their repost text
        JTextArea textField = new JTextArea(5,50);
        textField.setForeground(Color.BLACK);
        textField.setLineWrap(true);
        textField.setWrapStyleWord(true);
        JPanel repostPanel = new JPanel();
        repostPanel.add(textField);

        // this will allow the user to cancel or post their repost after they add text
        // if their is no text and they click repost, it is not posted
        JButton repost = new JButton("Repost");
        repost.addActionListener((ActionEvent e) -> {
            if (!textField.getText().equals("")) {
                Post newRepost = new Repost(textField.getText(), NetworkSystem.getInstance().getCurrentUser(), post);
                newRepost.setCategory(post.getCategory());
                NetworkSystem.getInstance().addPosts(newRepost);
            }
            repostFrame.dispose();
        });
        JButton cancel = new JButton("Cancel");
        cancel.addActionListener((ActionEvent e) -> {
            repostFrame.dispose();
        });
        
        // create a new panel for the buttons to be next to each other 
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1,2));
        buttonPanel.add(repost);
        buttonPanel.add(cancel);
        

        // this will combine the panels into the frame
        repostFrame.add(post.getThisPostPanel(), BorderLayout.NORTH);
        repostFrame.add(repostPanel, BorderLayout.CENTER);
        repostFrame.add(buttonPanel, BorderLayout.SOUTH);
        repostFrame.setSize(500, 600);
        repostFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        repostFrame.setVisible(true);
        System.out.println("clicked repost");
        // return repostFrame;  

    }
    

    /**
     * Handles the Delete action, prompting the user for confirmation and deleting the post if confirmed.
     * @precondition The action command of the event must be "Delete".
     * @postcondition If confirmed, the post is deleted from the network system, and the profile feed is refreshed.
     */
    private void handleDeleteAction() {
        //set up the asking to confirm 
        JFrame askingFrame = new JFrame("Confirm");
        askingFrame.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        JLabel command = new JLabel("Confirm to delete this post ?");
        JButton confirm = new JButton("Confirm");
        confirm.addActionListener((ActionEvent e) -> {
            askingFrame.dispose();
            NetworkSystem.getInstance().removePost(post);
            NetworkSystem.getInstance().getNetworkWindow().getProfilePagePanel().refreshProfileFeed();
        });
        JButton cancel = new JButton("Cancel");
        cancel.addActionListener((ActionEvent e) -> {
            askingFrame.dispose();
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(confirm);
        buttonPanel.add(cancel);

        c.gridx = 0;
        c.gridy = 0;
        askingFrame.add(command, c);

        c.gridx = 1;
        c.gridy = 0;
        askingFrame.add(buttonPanel, c);

        askingFrame.pack();
        askingFrame.setVisible(true);
    }
}