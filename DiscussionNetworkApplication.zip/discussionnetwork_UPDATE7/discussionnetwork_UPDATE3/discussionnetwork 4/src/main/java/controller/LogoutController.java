package controller;
import java.awt.event.*;
import javax.swing.*;

import core.NetworkSystem;
import gui.LogoutPanel;

/* Selin Topac */

public class LogoutController {
    private LogoutPanel logoutwindowView;
    private NetworkSystem currentSystem;
    
    
        /* Constructor for LogoutController */
        public LogoutController(LogoutPanel lView, NetworkSystem curSystem) {
            this.logoutwindowView = lView;
            this.currentSystem = curSystem;
            this.createListeners();
        }
    

    public void createListeners(){
        JButton logoutButton = this.logoutwindowView.getLogoutButton();
        
        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event){
                System.out.println("Logout button clicked");
                currentSystem.logout();

                //System.exit(0);
                
                
            }
        });
    }
    
}
