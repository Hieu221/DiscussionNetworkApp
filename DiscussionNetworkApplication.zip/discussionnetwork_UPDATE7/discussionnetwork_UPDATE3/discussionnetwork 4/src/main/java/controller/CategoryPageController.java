package controller;

import gui.CategoryPage;


/**
 * @author Lewis Cox
 * CategoryPageController is the logic behind updating posts 
 * it gets posts by category and updates the view accordingly
 */
public class CategoryPageController {

    private CategoryPage categoryPage;

    /**
     * constructs a CategoryPageController with the given CategoryPage
     * 
     * @param categoryPage CategoryPage instance to be controlled
     */
    public CategoryPageController(CategoryPage categoryPage) {
        this.categoryPage = categoryPage;
    }

    /**
     * updates the CategoryPage with posts from the specified category
     * 
     * @param category The category to filter posts by
     */
    public void updateCategoryPosts(String category) {
        categoryPage.updateCategoryPosts(category);
    }
}