How to run the DiscussionNetworkApplicaiton

Start off by downloading the DiscussionNetworkApplication.zip file. Once the file is downloaded open up the zip and extract all. Open up from the extracted folder. Open the file to show the discussionnetwork_UPDATE3. Now open the DiscussionNetworkApplication.jar file. If user windows the user is able to Open the .jar file within the Application folder, and the user will be brought to the login window of the Application. If the user is on mac, the user will have to right click on the .jar file. Select open with javaLauncher and the application will run.



To open up java document file, after extracting all from zip:

Open apidocs,then apidocs, then discussionNetwork_allclasses-index.html

